"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { engagementService } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/components/ui/toast";
import { hapticImpact } from "@/lib/telegram";
import { errorMessage } from "@/lib/use-api";

/** Saqlangan muassasalar ro'yxati va almashtirish (faqat kirgan foydalanuvchi uchun) */
export function useFavorites() {
  const { user } = useAuth();
  const router = useRouter();
  const toast = useToast();
  const [ids, setIds] = useState<Set<number>>(new Set());
  const userId = user?.id ?? null;

  useEffect(() => {
    if (userId === null) return;
    let alive = true;
    engagementService
      .getFavorites()
      .then((favs) => {
        if (alive) setIds(new Set(favs.map((f) => f.venue.id)));
      })
      .catch(() => {
        // Saqlanganlar yuklanmasa ham asosiy ro'yxat ishlayveradi; yurakchalar bo'sh ko'rinadi
      });
    return () => {
      alive = false;
    };
  }, [userId]);

  const toggle = useCallback(
    async (venueId: number) => {
      if (userId === null) {
        toast("Saqlash uchun akkauntga kiring");
        router.push("/login");
        return;
      }
      hapticImpact("light");
      try {
        const res = await engagementService.toggleFavorite(venueId);
        setIds((prev) => {
          const next = new Set(prev);
          if (res.is_favorite) next.add(venueId);
          else next.delete(venueId);
          return next;
        });
        toast(res.is_favorite ? "Saqlanganlarga qo'shildi" : "Saqlanganlardan olib tashlandi");
      } catch (err) {
        toast(errorMessage(err), "error");
      }
    },
    [userId, router, toast]
  );

  return { ids: userId === null ? new Set<number>() : ids, toggle };
}
