"use client";

import { useCallback } from "react";
import { useToast } from "@/components/ui/toast";

/** Joriy sahifa havolasini ulashish: tizim oynasi yoki buferga nusxalash */
export function useShare() {
  const toast = useToast();
  return useCallback(
    async (title: string) => {
      const url = window.location.href;
      if (navigator.share) {
        try {
          await navigator.share({ title, url });
          return;
        } catch {
          // Foydalanuvchi oynani yopdi — nusxalashga o'tmaymiz
          return;
        }
      }
      try {
        await navigator.clipboard.writeText(url);
        toast("Havola nusxalandi");
      } catch {
        toast("Havolani nusxalab bo'lmadi", "error");
      }
    },
    [toast]
  );
}
