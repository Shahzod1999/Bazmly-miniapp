"use client";

import React, { useState } from "react";
import { Bell } from "lucide-react";
import { Sheet } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { useToast } from "@/components/ui/toast";
import { engagementService } from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { errorMessage, useApiQuery } from "@/lib/use-api";

interface NotificationsSheetProps {
  open: boolean;
  onClose: () => void;
  /** O'qilmaganlar soni o'zgarganda (masalan, hammasi o'qildi) */
  onUnreadChange?: (count: number) => void;
}

export function NotificationsSheet({ open, onClose, onUnreadChange }: NotificationsSheetProps) {
  const toast = useToast();
  const [marking, setMarking] = useState(false);
  const query = useApiQuery(open ? "notifications" : null, () => engagementService.getNotifications(30));
  const { state } = query;

  const hasUnread = state.status === "success" && state.data.items.some((n) => !n.read_at);

  const markAllRead = async () => {
    setMarking(true);
    try {
      await engagementService.markAllNotificationsRead();
      const now = new Date().toISOString();
      query.setData((page) => ({ ...page, items: page.items.map((n) => ({ ...n, read_at: n.read_at ?? now })) }));
      onUnreadChange?.(0);
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setMarking(false);
    }
  };

  return (
    <Sheet open={open} onClose={onClose} title="Xabarnomalar">
      {state.status === "loading" && (
        <LoadingBlock>
          <div className="space-y-3 pt-2">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-20" />
            ))}
          </div>
        </LoadingBlock>
      )}
      {state.status === "error" && <ErrorState message={state.error.message} onRetry={query.retry} />}
      {state.status === "success" && state.data.items.length === 0 && (
        <EmptyState icon={<Bell className="h-10 w-10" />} title="Xabarnomalar yo'q" text="Bron holati o'zgarganda shu yerda xabar olasiz." />
      )}
      {state.status === "success" && state.data.items.length > 0 && (
        <>
          {hasUnread && (
            <div className="flex justify-end">
              <Button variant="ghost" size="md" onClick={markAllRead} loading={marking}>
                Hammasini o&apos;qilgan deb belgilash
              </Button>
            </div>
          )}
          <ul className="space-y-2 pt-1">
            {state.data.items.map((item) => (
              <li
                key={item.id}
                className={`rounded-card border p-4 ${item.read_at ? "border-border bg-surface-100" : "border-transparent bg-brand-tint"}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <p className="font-bold text-ink">{item.title}</p>
                  {!item.read_at && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand" aria-label="O'qilmagan" />}
                </div>
                <p className="mt-1 text-sm text-ink-muted">{item.body}</p>
                <p className="mt-2 text-xs font-medium text-ink-muted">{formatDateTime(item.sent_at)}</p>
              </li>
            ))}
          </ul>
        </>
      )}
    </Sheet>
  );
}
