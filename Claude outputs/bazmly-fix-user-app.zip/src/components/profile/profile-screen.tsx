"use client";

import React, { useState } from "react";
import Link from "next/link";
import { Bell, ChevronRight, Heart, LifeBuoy, LogOut, Moon, Pencil, Sun, Ticket } from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { useToast } from "@/components/ui/toast";
import { ConfirmSheet } from "@/components/ui/confirm-sheet";
import { SharePhoneBanner } from "@/components/auth/share-phone-banner";
import { useAuth, fullNameOf } from "@/contexts/AuthContext";
import { formatPhone } from "@/lib/format";
import { useIsTelegram } from "@/lib/telegram";
import { errorMessage } from "@/lib/use-api";
import { NotificationsSheet } from "./notifications-sheet";
import { EditProfileSheet } from "./edit-profile-sheet";
import { HelpSheet } from "./help-sheet";

type Panel = "notifications" | "edit" | "help" | "logout" | "delete" | null;

const ROW_CLASS =
  "flex min-h-14 w-full items-center gap-3 px-4 py-3 text-left text-[15px] font-semibold text-ink active:bg-surface-200";

export function ProfileScreen() {
  const { user, logout, deleteAccount } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const isTelegram = useIsTelegram();
  const toast = useToast();
  const [panel, setPanel] = useState<Panel>(null);
  const [busy, setBusy] = useState(false);

  const name = fullNameOf(user) || "Foydalanuvchi";
  const initials = name
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const close = () => setPanel(null);

  const handleLogout = async () => {
    setBusy(true);
    try {
      await logout();
      toast("Akkauntdan chiqildi");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setBusy(false);
      close();
    }
  };

  const handleDelete = async () => {
    setBusy(true);
    try {
      await deleteAccount();
      toast("Akkaunt o'chirildi");
      close();
    } catch (err) {
      toast(errorMessage(err, "Akkauntni o'chirib bo'lmadi"), "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex-1 px-4 pt-[calc(var(--tg-safe-top)+16px)]">
      <h1 className="text-[22px] font-extrabold tracking-tight text-ink">Profil</h1>

      <section className="mt-4 flex items-center gap-4 rounded-card bg-surface-100 p-4 shadow-[0_2px_12px_rgba(28,20,16,0.06)]">
        <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-brand-tint text-xl font-extrabold text-brand-strong" aria-hidden="true">
          {initials}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-lg font-bold text-ink">{name}</p>
          {user?.phone && <p className="text-sm text-ink-muted">{formatPhone(user.phone)}</p>}
        </div>
        <button
          type="button"
          onClick={() => setPanel("edit")}
          aria-label="Profilni tahrirlash"
          className="flex h-11 w-11 items-center justify-center rounded-full bg-surface-200 text-ink"
        >
          <Pencil className="h-5 w-5" aria-hidden="true" />
        </button>
      </section>

      <div className="mt-4">
        <SharePhoneBanner />
      </div>

      <ul className="mt-4 divide-y divide-border overflow-hidden rounded-card bg-surface-100 shadow-[0_2px_12px_rgba(28,20,16,0.06)]">
        <li>
          <button type="button" className={ROW_CLASS} onClick={() => setPanel("notifications")}>
            <Bell className="h-5 w-5 text-ink-muted" aria-hidden="true" />
            <span className="flex-1">Xabarnomalar</span>
            <ChevronRight className="h-5 w-5 text-ink-muted" aria-hidden="true" />
          </button>
        </li>
        <li>
          <Link href="/tickets" className={ROW_CLASS}>
            <Ticket className="h-5 w-5 text-ink-muted" aria-hidden="true" />
            <span className="flex-1">Bronlarim va chiptalar</span>
            <ChevronRight className="h-5 w-5 text-ink-muted" aria-hidden="true" />
          </Link>
        </li>
        <li>
          <Link href="/feed" className={ROW_CLASS}>
            <Heart className="h-5 w-5 text-ink-muted" aria-hidden="true" />
            <span className="flex-1">Saqlangan joylar</span>
            <ChevronRight className="h-5 w-5 text-ink-muted" aria-hidden="true" />
          </Link>
        </li>
        {!isTelegram && (
          <li>
            <button type="button" className={ROW_CLASS} onClick={toggleTheme} aria-pressed={theme === "dark"}>
              {theme === "dark" ? (
                <Moon className="h-5 w-5 text-ink-muted" aria-hidden="true" />
              ) : (
                <Sun className="h-5 w-5 text-ink-muted" aria-hidden="true" />
              )}
              <span className="flex-1">Tungi rejim</span>
              <span className="text-sm font-medium text-ink-muted">{theme === "dark" ? "Yoqilgan" : "O'chirilgan"}</span>
            </button>
          </li>
        )}
        <li>
          <button type="button" className={ROW_CLASS} onClick={() => setPanel("help")}>
            <LifeBuoy className="h-5 w-5 text-ink-muted" aria-hidden="true" />
            <span className="flex-1">Yordam</span>
            <ChevronRight className="h-5 w-5 text-ink-muted" aria-hidden="true" />
          </button>
        </li>
        <li>
          <button type="button" className={`${ROW_CLASS} text-danger`} onClick={() => setPanel("logout")}>
            <LogOut className="h-5 w-5" aria-hidden="true" />
            <span className="flex-1">Chiqish</span>
          </button>
        </li>
      </ul>

      <NotificationsSheet open={panel === "notifications"} onClose={close} />
      <EditProfileSheet open={panel === "edit"} onClose={close} onDeleteAccount={() => setPanel("delete")} />
      <HelpSheet open={panel === "help"} onClose={close} />
      <ConfirmSheet
        open={panel === "logout"}
        title="Akkauntdan chiqish"
        text="Haqiqatan ham akkauntdan chiqmoqchimisiz?"
        confirmText="Chiqish"
        danger
        loading={busy}
        onConfirm={handleLogout}
        onClose={close}
      />
      <ConfirmSheet
        open={panel === "delete"}
        title="Akkauntni o'chirish"
        text="Akkaunt va unga bog'liq ma'lumotlar o'chiriladi. Bu amalni qaytarib bo'lmaydi."
        confirmText="O'chirish"
        danger
        loading={busy}
        onConfirm={handleDelete}
        onClose={close}
      />
    </div>
  );
}
