"use client";

import React from "react";
import { ChevronDown, Send } from "lucide-react";
import { Sheet } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { openExternalLink } from "@/lib/telegram";

const SUPPORT_URL = "https://t.me/bazmly_support";

const FAQS = [
  {
    q: "Restoran yoki to'yxonani qanday bron qilaman?",
    a: "Bosh sahifada muassasani tanlang, sana, vaqt va mehmonlar sonini belgilang hamda bronni tasdiqlang. Bron \"Chiptalar\" bo'limida paydo bo'ladi va muassasa tasdiqlagach holati yangilanadi.",
  },
  {
    q: "Bronni qanday bekor qilaman?",
    a: "\"Chiptalar\" bo'limida bronni oching va \"Bronni bekor qilish\" tugmasini bosing. Bekor qilish shartlari muassasaga bog'liq.",
  },
  {
    q: "Chiptamni qayerdan topaman?",
    a: "Tasdiqlangan bronlarning QR kodi \"Chiptalar\" bo'limida turadi. Muassasaga kelganingizda shu kodni ko'rsatasiz.",
  },
];

export function HelpSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Yordam"
      footer={
        <Button fullWidth onClick={() => openExternalLink(SUPPORT_URL)}>
          <Send className="h-5 w-5" aria-hidden="true" />
          Qo&apos;llab-quvvatlashga yozish
        </Button>
      }
    >
      <div className="space-y-2 pt-2">
        {FAQS.map((item) => (
          <details key={item.q} className="group rounded-card border border-border bg-surface-100">
            <summary className="flex min-h-14 cursor-pointer list-none items-center justify-between gap-3 px-4 py-3 font-semibold text-ink">
              {item.q}
              <ChevronDown className="h-5 w-5 shrink-0 text-ink-muted transition-transform group-open:rotate-180" aria-hidden="true" />
            </summary>
            <p className="px-4 pb-4 text-[15px] leading-relaxed text-ink-muted">{item.a}</p>
          </details>
        ))}
      </div>
    </Sheet>
  );
}
