"use client";

import React, { useState } from "react";
import { Sheet } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { useToast } from "@/components/ui/toast";
import { useAuth } from "@/contexts/AuthContext";
import { errorMessage } from "@/lib/use-api";

interface EditProfileSheetProps {
  open: boolean;
  onClose: () => void;
  onDeleteAccount: () => void;
}

export function EditProfileSheet({ open, onClose, onDeleteAccount }: EditProfileSheetProps) {
  return (
    <Sheet open={open} onClose={onClose} title="Profilni tahrirlash">
      {/* Har ochilganda forma joriy ma'lumot bilan qaytadan to'ldiriladi */}
      {open && <EditProfileForm onSaved={onClose} onDeleteAccount={onDeleteAccount} />}
    </Sheet>
  );
}

function EditProfileForm({ onSaved, onDeleteAccount }: { onSaved: () => void; onDeleteAccount: () => void }) {
  const { user, updateProfile } = useAuth();
  const toast = useToast();
  const [firstName, setFirstName] = useState(user?.first_name ?? "");
  const [lastName, setLastName] = useState(user?.last_name ?? "");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim()) {
      setError("Ism bo'sh bo'lishi mumkin emas");
      return;
    }
    setSaving(true);
    try {
      await updateProfile({ first_name: firstName.trim(), last_name: lastName.trim() });
      toast("Profil saqlandi");
      onSaved();
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-4 pt-2">
      <Field label="Ism" autoComplete="given-name" value={firstName} onChange={(e) => setFirstName(e.target.value)} error={error} />
      <Field label="Familiya" autoComplete="family-name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
      <Button type="submit" fullWidth loading={saving}>
        Saqlash
      </Button>

      <div className="border-t border-border pt-4">
        <Button variant="danger" fullWidth size="md" onClick={onDeleteAccount}>
          Akkauntni o&apos;chirish
        </Button>
      </div>
    </form>
  );
}
