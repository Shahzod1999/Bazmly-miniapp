"use client";

import React, { useState } from "react";
import { MessageCircle, Send } from "lucide-react";
import { Sheet } from "@/components/ui/sheet";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { useToast } from "@/components/ui/toast";
import { engagementService, type MessageRead } from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { errorMessage, useApiQuery } from "@/lib/use-api";

interface ChatSheetProps {
  venueId: number;
  venueName: string;
  open: boolean;
  onClose: () => void;
}

export function ChatSheet({ venueId, venueName, open, onClose }: ChatSheetProps) {
  const toast = useToast();
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);

  const query = useApiQuery(open ? `chat:${venueId}` : null, async () => {
    const conversation = await engagementService.createConversation(venueId);
    const messages = await engagementService.getMessages(conversation.id);
    return { conversationId: conversation.id, messages };
  });
  const { state } = query;

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    const body = text.trim();
    if (!body || state.status !== "success") return;
    setSending(true);
    try {
      const message = await engagementService.sendMessage(state.data.conversationId, body);
      query.setData((prev) => ({ ...prev, messages: [...prev.messages, message] }));
      setText("");
    } catch (err) {
      toast(errorMessage(err, "Xabar yuborilmadi"), "error");
    } finally {
      setSending(false);
    }
  };

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title={venueName}
      footer={
        state.status === "success" && (
          <form onSubmit={send} className="flex items-center gap-2">
            <label className="flex h-12 flex-1 items-center rounded-control bg-surface-200 px-4">
              <span className="sr-only">Xabar</span>
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Xabar yozing..."
                className="h-full w-full bg-transparent text-base text-ink outline-none placeholder:text-ink-muted"
              />
            </label>
            <button
              type="submit"
              disabled={!text.trim() || sending}
              aria-label="Yuborish"
              className="flex h-12 w-12 items-center justify-center rounded-control bg-brand text-on-brand disabled:opacity-50"
            >
              <Send className="h-5 w-5" aria-hidden="true" />
            </button>
          </form>
        )
      }
    >
      {state.status === "loading" && (
        <LoadingBlock>
          <div className="space-y-3 pt-2">
            <Skeleton className="h-12 w-2/3" />
            <Skeleton className="ml-auto h-12 w-1/2" />
          </div>
        </LoadingBlock>
      )}
      {state.status === "error" && <ErrorState message={state.error.message} onRetry={query.retry} />}
      {state.status === "success" && state.data.messages.length === 0 && (
        <EmptyState icon={<MessageCircle className="h-10 w-10" />} title="Savolingizni yozing" text="Muassasa ma'muriyati shu yerda javob beradi." />
      )}
      {state.status === "success" && state.data.messages.length > 0 && (
        <ul className="space-y-2 pt-2" aria-live="polite">
          {state.data.messages.map((m) => (
            <MessageBubble key={m.id} message={m} />
          ))}
        </ul>
      )}
    </Sheet>
  );
}

function MessageBubble({ message }: { message: MessageRead }) {
  const mine = message.sender_type === "user";
  return (
    <li className={`flex ${mine ? "justify-end" : "justify-start"}`}>
      <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${mine ? "bg-brand-tint text-ink" : "bg-surface-200 text-ink"}`}>
        <p className="whitespace-pre-wrap text-[15px]">{message.body}</p>
        <p className="mt-1 text-xs text-ink-muted">{formatDateTime(message.created_at)}</p>
      </div>
    </li>
  );
}
