"use client";

import React, { useState } from "react";
import Image from "next/image";
import { Heart, ImageOff, Share2 } from "lucide-react";
import { IconButton } from "@/components/ui/button";
import type { VenuePhotoRead } from "@/lib/api";

interface VenueGalleryProps {
  name: string;
  photos: VenuePhotoRead[];
  isFavorite: boolean;
  onToggleFavorite: () => void;
  onShare: () => void;
  /** Brauzerda chap yuqoridagi orqaga tugmasi (Telegram ichida tizim tugmasi) */
  backButton?: React.ReactNode;
}

export function VenueGallery({ name, photos, isFavorite, onToggleFavorite, onShare, backButton }: VenueGalleryProps) {
  const sorted = [...photos].sort((a, b) => Number(b.is_cover) - Number(a.is_cover) || a.sort_order - b.sort_order);
  const [activeId, setActiveId] = useState<number | null>(sorted[0]?.id ?? null);
  const active = sorted.find((p) => p.id === activeId) ?? sorted[0];

  return (
    <div className="relative h-72 w-full overflow-hidden bg-surface-200">
      {active ? (
        <Image src={active.url} alt={name} fill priority unoptimized sizes="448px" className="object-cover" />
      ) : (
        <div className="flex h-full items-center justify-center text-ink-muted">
          <ImageOff className="h-10 w-10" aria-hidden="true" />
        </div>
      )}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/40" />

      <div className="absolute inset-x-3 top-[calc(var(--tg-safe-top)+12px)] flex items-center justify-between">
        <div>{backButton}</div>
        <div className="flex gap-2">
          <IconButton label="Ulashish" tone="overlay" onClick={onShare}>
            <Share2 className="h-5 w-5" aria-hidden="true" />
          </IconButton>
          <IconButton label={isFavorite ? "Saqlanganlardan olib tashlash" : "Saqlash"} aria-pressed={isFavorite} tone="overlay" onClick={onToggleFavorite}>
            <Heart className={`h-5 w-5 ${isFavorite ? "fill-brand text-brand" : ""}`} aria-hidden="true" />
          </IconButton>
        </div>
      </div>

      {sorted.length > 1 && (
        <div className="scrollbar-none absolute inset-x-0 bottom-3 flex justify-center gap-2 overflow-x-auto px-4">
          {sorted.map((photo, index) => (
            <button
              key={photo.id}
              type="button"
              onClick={() => setActiveId(photo.id)}
              aria-label={`${index + 1}-rasm`}
              aria-current={photo.id === active?.id}
              className={`relative h-11 w-11 shrink-0 overflow-hidden rounded-xl border-2 ${
                photo.id === active?.id ? "border-brand" : "border-white/80"
              }`}
            >
              <Image src={photo.url} alt="" fill unoptimized sizes="44px" className="object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
