import React from "react";
import { BadgePercent, Clock, MapPin, Star, Users } from "lucide-react";
import type { VenueDetailRead } from "@/lib/api";
import { formatRating, formatSom, formatTime } from "@/lib/format";

/** Bugungi ish vaqti (API'da 0 = dushanba) */
function todayHours(detail: VenueDetailRead): string | null {
  const weekday = (new Date().getDay() + 6) % 7;
  const today = detail.working_hours.find((h) => h.weekday === weekday);
  if (!today) return null;
  if (today.is_closed) return "Bugun dam olish kuni";
  if (!today.opens_at || !today.closes_at) return null;
  return `Bugun ${formatTime(today.opens_at)} – ${formatTime(today.closes_at)}`;
}

function capacityText(min: number | null, max: number | null, seats: number | null): string | null {
  if (min && max) return `${min} – ${max} kishi`;
  if (max) return `${max} kishigacha`;
  if (seats) return `${seats} o'rin`;
  return null;
}

interface VenueInfoProps {
  detail: VenueDetailRead;
  onOpenReviews: () => void;
  /** Masalan: "Joy narxi" yoki "Zal narxi" */
  priceLabel?: string;
}

export function VenueInfo({ detail, onOpenReviews, priceLabel = "Narx" }: VenueInfoProps) {
  const { venue } = detail;
  const rating = formatRating(venue.rating_avg);
  const hours = todayHours(detail);
  const capacity = capacityText(venue.capacity_min, venue.capacity_max, venue.total_seats);
  const discount = Number(venue.discount_percent || 0);

  return (
    <section className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {discount > 0 && (
          <span className="inline-flex items-center gap-1 rounded-full bg-success-tint px-3 py-1 text-xs font-semibold text-success">
            <BadgePercent className="h-4 w-4" aria-hidden="true" />
            {discount}% chegirma
          </span>
        )}
        {venue.requires_deposit && (
          <span className="rounded-full bg-success-tint px-3 py-1 text-xs font-semibold text-success">
            Depozitlik{venue.deposit_percent ? ` · ${Number(venue.deposit_percent)}%` : ""}
          </span>
        )}
      </div>

      <div className="flex items-start justify-between gap-3">
        <h1 className="text-2xl font-extrabold tracking-tight text-ink">{venue.name}</h1>
        <span className={`mt-1.5 shrink-0 text-sm font-bold ${detail.is_open_now ? "text-success" : "text-danger"}`}>
          {detail.is_open_now ? "Ochiq" : "Yopiq"}
        </span>
      </div>
      {venue.tagline && <p className="text-[15px] text-ink-muted">{venue.tagline}</p>}

      <button
        type="button"
        onClick={onOpenReviews}
        className="-ml-1 flex min-h-11 items-center gap-1.5 rounded-control px-1 text-sm font-semibold text-ink"
      >
        <Star className="h-4 w-4 fill-warning text-warning" aria-hidden="true" />
        {rating ? `${rating} · ${venue.reviews_count} ta sharh` : "Hali sharhlar yo'q"}
      </button>

      <ul className="space-y-2 text-[15px] text-ink">
        <li className="flex items-start gap-2.5">
          <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-ink-muted" aria-hidden="true" />
          {venue.street}
          {venue.house_number ? `, ${venue.house_number}` : ""}
        </li>
        {hours && (
          <li className="flex items-center gap-2.5">
            <Clock className="h-5 w-5 shrink-0 text-ink-muted" aria-hidden="true" />
            {hours}
          </li>
        )}
        {capacity && (
          <li className="flex items-center gap-2.5">
            <Users className="h-5 w-5 shrink-0 text-ink-muted" aria-hidden="true" />
            {capacity}
          </li>
        )}
      </ul>

      {venue.base_price && Number(venue.base_price) > 0 && (
        <p className="text-sm text-ink-muted">
          {priceLabel}: <span className="text-lg font-extrabold text-brand-strong">{formatSom(venue.base_price)}</span> dan
        </p>
      )}

      {venue.description && (
        <div className="pt-2">
          <h2 className="text-base font-bold text-ink">Tavsif</h2>
          <p className="mt-1 text-[15px] leading-relaxed text-ink-muted">{venue.description}</p>
        </div>
      )}

      {detail.amenities.length > 0 && (
        <div className="pt-2">
          <h2 className="text-base font-bold text-ink">Qulayliklar</h2>
          <ul className="mt-2 flex flex-wrap gap-2">
            {detail.amenities.map((a) => (
              <li key={a.id} className="rounded-full bg-surface-200 px-3 py-1.5 text-sm font-medium text-ink">
                {a.name}
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
