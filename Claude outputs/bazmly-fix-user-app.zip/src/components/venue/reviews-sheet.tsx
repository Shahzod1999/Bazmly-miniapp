"use client";

import React from "react";
import { MessageSquare, Star } from "lucide-react";
import { Sheet } from "@/components/ui/sheet";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { venueService } from "@/lib/api";
import { formatDateTime, formatRating } from "@/lib/format";
import { useApiQuery } from "@/lib/use-api";

interface ReviewsSheetProps {
  venueId: number;
  open: boolean;
  onClose: () => void;
}

export function ReviewsSheet({ venueId, open, onClose }: ReviewsSheetProps) {
  const query = useApiQuery(open ? `reviews:${venueId}` : null, async () => {
    const [aggregate, page] = await Promise.all([
      venueService.getReviewAggregate(venueId),
      venueService.getReviews(venueId, 30, 0),
    ]);
    return { aggregate, page };
  });
  const { state } = query;

  return (
    <Sheet open={open} onClose={onClose} title="Sharhlar">
      {state.status === "loading" && (
        <LoadingBlock>
          <div className="space-y-3 pt-2">
            <Skeleton className="h-16" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        </LoadingBlock>
      )}
      {state.status === "error" && <ErrorState message={state.error.message} onRetry={query.retry} />}
      {state.status === "success" && (
        <>
          <div className="flex items-center gap-3 rounded-card bg-surface-200 p-4">
            <Star className="h-8 w-8 fill-warning text-warning" aria-hidden="true" />
            <div>
              <p className="text-2xl font-extrabold text-ink">{formatRating(state.data.aggregate.average) || "—"}</p>
              <p className="text-sm text-ink-muted">{state.data.aggregate.count} ta sharh</p>
            </div>
          </div>
          {state.data.page.items.length === 0 ? (
            <EmptyState icon={<MessageSquare className="h-10 w-10" />} title="Hali sharhlar yo'q" text="Bu yerga birinchi bo'lib tashrif buyurganlar baho beradi." />
          ) : (
            <ul className="mt-3 space-y-3">
              {state.data.page.items.map((review) => (
                <li key={review.id} className="rounded-card border border-border p-4">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-bold text-ink">
                      {`${review.author.first_name} ${review.author.last_name}`.trim() || "Mehmon"}
                    </p>
                    <span className="inline-flex items-center gap-1 text-sm font-semibold text-ink" aria-label={`${review.rating} yulduz`}>
                      <Star className="h-4 w-4 fill-warning text-warning" aria-hidden="true" />
                      {review.rating}
                    </span>
                  </div>
                  {review.is_verified && <p className="mt-0.5 text-xs font-semibold text-success">Tasdiqlangan tashrif</p>}
                  {review.comment && <p className="mt-2 text-[15px] leading-relaxed text-ink-muted">{review.comment}</p>}
                  {review.published_at && <p className="mt-2 text-xs text-ink-muted">{formatDateTime(review.published_at)}</p>}
                </li>
              ))}
            </ul>
          )}
        </>
      )}
    </Sheet>
  );
}
