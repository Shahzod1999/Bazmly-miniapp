"use client";

import React, { useState } from "react";
import Image from "next/image";
import { Minus, Plus, Search, Utensils } from "lucide-react";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import type { MenuItemListItem } from "@/lib/api";
import { formatSom } from "@/lib/format";
import { hapticSelection } from "@/lib/telegram";
import type { ApiQuery } from "@/lib/use-api";

export type Cart = Record<number, number>;

interface VenueMenuProps {
  menu: ApiQuery<MenuItemListItem[]>;
  cart: Cart;
  onChange: (cart: Cart) => void;
}

/** Muassasa menyusi: taomlarni oldindan buyurtma uchun tanlash */
export function VenueMenu({ menu, cart, onChange }: VenueMenuProps) {
  const [search, setSearch] = useState("");

  const setQty = (itemId: number, qty: number) => {
    const next = { ...cart };
    if (qty <= 0) delete next[itemId];
    else next[itemId] = qty;
    onChange(next);
    hapticSelection();
  };

  return (
    <section aria-labelledby="menu-title" className="pt-6">
      <h2 id="menu-title" className="text-lg font-bold text-ink">
        Menyu
      </h2>
      <p className="mt-0.5 text-sm text-ink-muted">Taomlarni oldindan tanlasangiz, bron bilan birga yuboriladi.</p>

      {menu.state.status === "loading" && (
        <LoadingBlock label="Menyu yuklanmoqda">
          <div className="mt-3 space-y-3">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        </LoadingBlock>
      )}
      {menu.state.status === "error" && <ErrorState message={menu.state.error.message} onRetry={menu.retry} />}
      {menu.state.status === "success" && menu.state.data.length === 0 && (
        <EmptyState icon={<Utensils className="h-10 w-10" />} title="Menyu hali qo'shilmagan" text="Taomlar va narxlarni muassasaning o'zidan so'rashingiz mumkin." />
      )}
      {menu.state.status === "success" && menu.state.data.length > 0 && (
        <>
          <label className="mt-3 flex h-12 items-center gap-2 rounded-control bg-surface-200 px-3">
            <Search className="h-5 w-5 text-ink-muted" aria-hidden="true" />
            <span className="sr-only">Taom qidirish</span>
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Taom qidirish"
              className="h-full min-w-0 flex-1 bg-transparent text-base text-ink outline-none placeholder:text-ink-muted"
            />
          </label>
          <ul className="mt-3 space-y-3">
            {menu.state.data
              .filter((item) => item.status === "active" && item.name.toLowerCase().includes(search.trim().toLowerCase()))
              .map((item) => (
                <MenuRow key={item.id} item={item} qty={cart[item.id] ?? 0} onQty={(q) => setQty(item.id, q)} />
              ))}
          </ul>
        </>
      )}
    </section>
  );
}

function MenuRow({ item, qty, onQty }: { item: MenuItemListItem; qty: number; onQty: (qty: number) => void }) {
  const unavailable = !item.is_available;
  return (
    <li className={`flex gap-3 rounded-card bg-surface-100 p-3 shadow-[0_2px_12px_rgba(28,20,16,0.06)] ${qty > 0 ? "ring-2 ring-brand" : ""}`}>
      <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-surface-200">
        {item.photo_url ? (
          <Image src={item.photo_url} alt="" fill unoptimized sizes="80px" className={`object-cover ${unavailable ? "opacity-50" : ""}`} />
        ) : (
          <div className="flex h-full items-center justify-center text-ink-muted">
            <Utensils className="h-6 w-6" aria-hidden="true" />
          </div>
        )}
      </div>
      <div className="flex min-w-0 flex-1 flex-col">
        <p className="font-bold text-ink">{item.name}</p>
        <div className="mt-auto flex items-end justify-between gap-2 pt-2">
          <span className={`font-extrabold ${unavailable ? "text-ink-muted" : "text-brand-strong"}`}>
            {item.effective_price ? formatSom(item.effective_price) : "Narx so'raladi"}
          </span>
          {unavailable ? (
            <span className="rounded-lg bg-surface-200 px-2.5 py-1 text-xs font-semibold text-ink">Hozircha yo&apos;q</span>
          ) : qty === 0 ? (
            <button
              type="button"
              onClick={() => onQty(1)}
              aria-label={`${item.name} — qo'shish`}
              className="flex h-11 w-11 items-center justify-center rounded-control bg-brand-tint text-brand-strong"
            >
              <Plus className="h-5 w-5" aria-hidden="true" />
            </button>
          ) : (
            <div className="flex items-center rounded-control bg-brand-tint">
              <button type="button" onClick={() => onQty(qty - 1)} aria-label={`${item.name} — kamaytirish`} className="flex h-11 w-10 items-center justify-center text-brand-strong">
                <Minus className="h-4 w-4" aria-hidden="true" />
              </button>
              <span aria-live="polite" className="min-w-5 text-center font-bold tabular-nums text-ink">
                {qty}
              </span>
              <button type="button" onClick={() => onQty(qty + 1)} aria-label={`${item.name} — ko'paytirish`} className="flex h-11 w-10 items-center justify-center text-brand-strong">
                <Plus className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          )}
        </div>
      </div>
    </li>
  );
}

/** Savatdagi taomlar soni va summasi */
export function cartSummary(cart: Cart, items: MenuItemListItem[]): { count: number; total: number } {
  let count = 0;
  let total = 0;
  for (const [id, qty] of Object.entries(cart)) {
    const item = items.find((i) => i.id === Number(id));
    count += qty;
    total += qty * Number(item?.effective_price ?? 0);
  }
  return { count, total };
}

/** Savatni URL parametri ko'rinishiga o'tkazish: "12:2,15:1" */
export function encodeCart(cart: Cart): string {
  return Object.entries(cart)
    .map(([id, qty]) => `${id}:${qty}`)
    .join(",");
}

export function decodeCart(value: string | null): Cart {
  const cart: Cart = {};
  if (!value) return cart;
  for (const part of value.split(",")) {
    const [id, qty] = part.split(":").map(Number);
    if (Number.isInteger(id) && id > 0 && Number.isInteger(qty) && qty > 0) cart[id] = qty;
  }
  return cart;
}
