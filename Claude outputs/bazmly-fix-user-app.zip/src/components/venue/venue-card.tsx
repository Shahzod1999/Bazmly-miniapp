"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import { Heart, ImageOff, Star } from "lucide-react";
import type { VenueListItem } from "@/lib/api";
import { formatDistance, formatRating, formatSom } from "@/lib/format";

interface VenueCardProps {
  venue: VenueListItem;
  href: string;
  isFavorite?: boolean;
  onToggleFavorite?: (venueId: number) => void;
  /** Birinchi ekrandagi rasm uchun (LCP) */
  priority?: boolean;
}

export function VenueCard({ venue, href, isFavorite = false, onToggleFavorite, priority = false }: VenueCardProps) {
  const rating = formatRating(venue.rating_avg);
  const distance = formatDistance(venue.distance_m);

  return (
    <article className="relative overflow-hidden rounded-card bg-surface-100 shadow-[0_2px_12px_rgba(28,20,16,0.06)]">
      <Link href={href} className="block">
        <div className="relative aspect-[16/9] bg-surface-200">
          {venue.cover_url ? (
            <Image
              src={venue.cover_url}
              alt=""
              fill
              sizes="(max-width: 448px) 100vw, 448px"
              priority={priority}
              unoptimized
              className="object-cover"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-ink-muted">
              <ImageOff className="h-8 w-8" aria-hidden="true" />
            </div>
          )}
          {venue.discount_percent && Number(venue.discount_percent) > 0 && (
            <span className="absolute left-3 top-3 rounded-lg bg-success px-2.5 py-1 text-xs font-bold text-white">
              -{Number(venue.discount_percent)}%
            </span>
          )}
        </div>
        <div className="p-4">
          <div className="flex items-start justify-between gap-3 pr-10">
            <h3 className="text-[17px] font-bold leading-6 text-ink">{venue.name}</h3>
          </div>
          {venue.tagline && <p className="mt-0.5 line-clamp-1 text-sm text-ink-muted">{venue.tagline}</p>}
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] font-medium text-ink-muted">
            {rating && (
              <span className="inline-flex items-center gap-1 text-ink">
                <Star className="h-4 w-4 fill-warning text-warning" aria-hidden="true" />
                {rating}
                <span className="text-ink-muted">({venue.reviews_count})</span>
              </span>
            )}
            <span className={venue.is_open_now ? "font-semibold text-success" : "font-semibold text-danger"}>
              {venue.is_open_now ? "Ochiq" : "Yopiq"}
            </span>
            {distance && <span>{distance}</span>}
            {venue.requires_deposit && (
              <span className="rounded-md bg-success-tint px-2 py-0.5 text-xs font-semibold text-success">Depozitlik</span>
            )}
          </div>
          {venue.base_price && Number(venue.base_price) > 0 && (
            <p className="mt-3 text-[15px] font-extrabold text-brand-strong">{formatSom(venue.base_price)} dan</p>
          )}
        </div>
      </Link>
      {onToggleFavorite && (
        <button
          type="button"
          onClick={() => onToggleFavorite(venue.id)}
          aria-label={isFavorite ? "Saqlanganlardan olib tashlash" : "Saqlash"}
          aria-pressed={isFavorite}
          className="absolute right-2 top-[calc(56.25%+8px)] flex h-11 w-11 items-center justify-center rounded-full text-ink-muted active:bg-surface-200"
        >
          <Heart className={`h-5 w-5 ${isFavorite ? "fill-brand text-brand" : ""}`} aria-hidden="true" />
        </button>
      )}
    </article>
  );
}

export function VenueCardSkeleton() {
  return (
    <div aria-hidden="true" className="overflow-hidden rounded-card bg-surface-100">
      <div className="skeleton aspect-[16/9]" />
      <div className="space-y-2 p-4">
        <div className="skeleton h-5 w-2/3 rounded-md" />
        <div className="skeleton h-4 w-1/2 rounded-md" />
        <div className="skeleton h-4 w-1/3 rounded-md" />
      </div>
    </div>
  );
}

/** Muassasa turiga qarab sahifa manzili */
export function venueHref(venueId: number, type?: "restoran" | "toyxona" | string | null): string {
  return type === "toyxona" ? `/toyxona/${venueId}` : `/venue/${venueId}`;
}
