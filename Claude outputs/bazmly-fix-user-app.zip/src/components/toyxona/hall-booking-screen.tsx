"use client";

import React, { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { PageHeader } from "@/components/ui/page-header";
import { BottomAction, BottomActionSpacer } from "@/components/ui/bottom-action";
import { ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { useToast } from "@/components/ui/toast";
import { RequireAuth } from "@/components/auth/require-auth";
import { Counter, DatePicker, SectionTitle, TimePicker } from "@/components/booking/pickers";
import { ContactFields, contactErrors, contactFromUser, type ContactValue } from "@/components/booking/contact-fields";
import { HallServicesPicker } from "./hall-services";
import { GUEST_STEP, MAX_GUESTS } from "@/components/toyxona-menu/types";
import { useAuth } from "@/contexts/AuthContext";
import { bookingService, venueService } from "@/lib/api";
import { timeSlots, upcomingDates } from "@/lib/booking";
import { addMinutes, formatTime, toApiTime, toE164Uz } from "@/lib/format";
import { hapticNotify, hapticSelection } from "@/lib/telegram";
import { errorMessage, useApiQuery } from "@/lib/use-api";

const DAYS_AHEAD = 120;
const DURATIONS = [3, 4, 5, 6];

export function HallBookingScreen() {
  return (
    <RequireAuth title="Sanani band qilish">
      <HallBookingForm />
    </RequireAuth>
  );
}

function HallBookingForm() {
  const { id } = useParams<{ id: string }>();
  const venueId = Number(id);
  const router = useRouter();
  const { user } = useAuth();
  const toast = useToast();

  const [now] = useState(() => new Date());
  const [allDates] = useState(() => upcomingDates(DAYS_AHEAD));
  const [guests, setGuests] = useState<number | null>(null);
  const [date, setDate] = useState<string | null>(null);
  const [hours, setHours] = useState(5);
  const [time, setTime] = useState<string | null>(null);
  const [services, setServices] = useState<Set<number>>(() => new Set());
  const [contact, setContact] = useState<ContactValue>(() => contactFromUser(user));
  const [showErrors, setShowErrors] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const detail = useApiQuery(`venue:${venueId}`, () => venueService.getVenueDetail(venueId));
  const venue = detail.state.status === "success" ? detail.state.data.venue : null;
  const dates = venue ? allDates.slice(Math.max(0, venue.min_advance_booking_days)) : [];

  const range = dates.length ? `${dates[0]}:${dates[dates.length - 1]}` : null;
  const blocked = useApiQuery(range ? `availability:${venueId}:${range}` : null, () =>
    venueService.getAvailability(venueId, dates[0], dates[dates.length - 1])
  );
  const blockedSet = new Set(blocked.state.status === "success" ? blocked.state.data.dates : []);

  const serviceQuery = useApiQuery(venue ? `services:${venueId}` : null, () =>
    venueService.getServices(venueId, (venue as NonNullable<typeof venue>).venue_group_id)
  );

  const minGuests = Math.max(1, venue?.capacity_min ?? 1);
  const maxGuests = venue?.capacity_max || MAX_GUESTS;
  const guestCount = guests ?? minGuests;
  const durationMin = hours * 60;
  const times = date && detail.state.status === "success" ? timeSlots(date, detail.state.data.working_hours, durationMin, now) : [];
  const endTime = time ? addMinutes(time, durationMin) : null;
  const errors = contactErrors(contact);

  const toggleService = (serviceId: number) =>
    setServices((prev) => {
      const next = new Set(prev);
      if (next.has(serviceId)) next.delete(serviceId);
      else next.add(serviceId);
      return next;
    });

  const submit = async () => {
    setShowErrors(true);
    if (!date || !time || !endTime) {
      toast("Sana va vaqtni tanlang", "error");
      return;
    }
    if (Object.keys(errors).length > 0) return;
    setSubmitting(true);
    setSubmitError(null);
    try {
      const result = await bookingService.bookHall({
        venue_id: venueId,
        booking_date: date,
        start_time: toApiTime(time),
        end_time: toApiTime(endTime),
        guests_count: guestCount,
        contact_name: contact.name.trim(),
        contact_phone: toE164Uz(contact.phoneDigits),
        note: contact.note.trim() || null,
        venue_service_ids: [...services],
      });
      hapticNotify("success");
      router.replace(`/payment/${result.booking.id}`);
    } catch (err) {
      hapticNotify("error");
      setSubmitError(errorMessage(err, "Sanani band qilib bo'lmadi. Qaytadan urinib ko'ring."));
      setSubmitting(false);
    }
  };

  if (detail.state.status === "loading") {
    return (
      <>
        <PageHeader title="Sanani band qilish" back />
        <LoadingBlock>
          <div className="space-y-4 p-4">
            <Skeleton className="h-16" />
            <Skeleton className="h-20" />
            <Skeleton className="h-32" />
          </div>
        </LoadingBlock>
      </>
    );
  }
  if (detail.state.status === "error") {
    return (
      <>
        <PageHeader title="Sanani band qilish" back />
        <ErrorState message={detail.state.error.message} onRetry={detail.retry} />
      </>
    );
  }

  return (
    <div className="flex-1">
      <PageHeader title="Sanani band qilish" subtitle={venue?.name} back />
      <div className="px-4 pt-4">
        <Counter
          label="Mehmonlar soni"
          hint={venue?.capacity_max ? `${minGuests} – ${maxGuests} kishi` : undefined}
          value={guestCount}
          onChange={setGuests}
          min={minGuests}
          max={maxGuests}
          step={GUEST_STEP}
        />

        <SectionTitle>Sana</SectionTitle>
        {blocked.state.status === "error" ? (
          <ErrorState message={blocked.state.error.message} onRetry={blocked.retry} />
        ) : (
          <DatePicker
            dates={dates}
            value={date}
            disabledDates={blockedSet}
            onChange={(d) => {
              setDate(d);
              setTime(null);
            }}
          />
        )}
        {blocked.state.status === "success" && blockedSet.size > 0 && (
          <p className="mt-2 text-sm text-ink-muted">Chizilgan sanalar band.</p>
        )}

        <SectionTitle>Davomiyligi</SectionTitle>
        <div role="radiogroup" aria-label="Davomiyligi" className="grid grid-cols-4 gap-2">
          {DURATIONS.map((h) => (
            <button
              key={h}
              type="button"
              role="radio"
              aria-checked={hours === h}
              onClick={() => {
                setHours(h);
                setTime(null);
                hapticSelection();
              }}
              className={`h-12 rounded-control text-[15px] font-semibold ${hours === h ? "bg-brand-strong text-on-brand" : "bg-surface-100 text-ink"}`}
            >
              {h} soat
            </button>
          ))}
        </div>

        {date && (
          <>
            <SectionTitle>Boshlanish vaqti</SectionTitle>
            <TimePicker times={times} value={time} onChange={setTime} />
            {time && endTime && (
              <p className="mt-2 text-sm text-ink-muted">
                Tadbir {formatTime(time)} – {formatTime(endTime)}
              </p>
            )}
          </>
        )}

        <SectionTitle>Qo&apos;shimcha xizmatlar</SectionTitle>
        <HallServicesPicker query={serviceQuery} selected={services} onToggle={toggleService} />
        <p className="mt-2 text-sm text-ink-muted">Yakuniy summani to&apos;yxona bron yaratilgach hisoblaydi.</p>

        <SectionTitle>Aloqa ma&apos;lumotlari</SectionTitle>
        <ContactFields value={contact} onChange={setContact} errors={showErrors ? errors : undefined} />

        {submitError && (
          <p role="alert" className="mt-4 rounded-control bg-danger-tint px-4 py-3 text-sm font-medium text-danger">
            {submitError}
          </p>
        )}
      </div>

      <BottomActionSpacer />
      <BottomAction
        text={submitError ? "Qayta urinish" : "Band qilish"}
        onClick={submit}
        loading={submitting}
        disabled={!date || !time || blockedSet.has(date)}
      />
    </div>
  );
}
