"use client";

import React from "react";
import { Check, Sparkles } from "lucide-react";
import { ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import type { ServicePriceUnit, VenueServiceRead } from "@/lib/api";
import { formatSom } from "@/lib/format";
import { hapticSelection } from "@/lib/telegram";
import type { ApiQuery } from "@/lib/use-api";

const UNIT: Record<ServicePriceUnit, string> = {
  per_event: "tadbir uchun",
  per_guest: "1 kishi uchun",
  per_hour: "1 soat uchun",
  fixed: "",
};

export function servicePrice(service: VenueServiceRead): string {
  const unit = UNIT[service.price_unit];
  return `${formatSom(service.price)}${unit ? ` · ${unit}` : ""}`;
}

function activeServices(data: VenueServiceRead[]): VenueServiceRead[] {
  return data.filter((s) => s.is_active).sort((a, b) => a.sort_order - b.sort_order);
}

function ServicesState({ query, children }: { query: ApiQuery<VenueServiceRead[]>; children: (items: VenueServiceRead[]) => React.ReactNode }) {
  const { state } = query;
  if (state.status === "loading") {
    return (
      <LoadingBlock label="Xizmatlar yuklanmoqda">
        <div className="space-y-2">
          <Skeleton className="h-16" />
          <Skeleton className="h-16" />
        </div>
      </LoadingBlock>
    );
  }
  if (state.status === "error") return <ErrorState message={state.error.message} onRetry={query.retry} />;
  const items = activeServices(state.data);
  if (items.length === 0) {
    return <p className="rounded-card bg-surface-100 px-4 py-4 text-[15px] text-ink-muted">Qo&apos;shimcha xizmatlar kiritilmagan.</p>;
  }
  return <>{children(items)}</>;
}

/** To'yxona sahifasida xizmatlar ro'yxati (faqat ko'rish) */
export function HallServicesList({ query }: { query: ApiQuery<VenueServiceRead[]> }) {
  return (
    <ServicesState query={query}>
      {(items) => (
        <ul className="divide-y divide-border rounded-card bg-surface-100 px-4">
          {items.map((service) => (
            <li key={service.id} className="py-3">
              <p className="font-semibold text-ink">{service.name}</p>
              <p className="text-sm text-ink-muted">{servicePrice(service)}</p>
              {service.items && service.items.length > 0 && (
                <p className="mt-1 text-sm text-ink-muted">{service.items.map((i) => i.name).join(", ")}</p>
              )}
            </li>
          ))}
        </ul>
      )}
    </ServicesState>
  );
}

interface HallServicesPickerProps {
  query: ApiQuery<VenueServiceRead[]>;
  selected: Set<number>;
  onToggle: (serviceId: number) => void;
}

/** Bron qilishda xizmatlarni tanlash */
export function HallServicesPicker({ query, selected, onToggle }: HallServicesPickerProps) {
  return (
    <ServicesState query={query}>
      {(items) => (
        <ul className="space-y-2">
          {items.map((service) => {
            const active = selected.has(service.id);
            return (
              <li key={service.id}>
                <button
                  type="button"
                  role="checkbox"
                  aria-checked={active}
                  onClick={() => {
                    onToggle(service.id);
                    hapticSelection();
                  }}
                  className={`flex w-full items-center gap-3 rounded-card border-2 bg-surface-100 p-4 text-left ${active ? "border-brand" : "border-transparent"}`}
                >
                  <span
                    aria-hidden="true"
                    className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2 ${active ? "border-brand-strong bg-brand-strong text-on-brand" : "border-border"}`}
                  >
                    {active ? <Check className="h-4 w-4" /> : <Sparkles className="h-3.5 w-3.5 text-ink-muted" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-semibold text-ink">{service.name}</span>
                    <span className="block text-sm text-ink-muted">{servicePrice(service)}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </ServicesState>
  );
}
