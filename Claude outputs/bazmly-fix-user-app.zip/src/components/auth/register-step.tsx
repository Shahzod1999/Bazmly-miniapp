"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { useAuth } from "@/contexts/AuthContext";
import { formatPhone } from "@/lib/format";
import { errorMessage } from "@/lib/use-api";

const MIN_PASSWORD = 8;

interface RegisterStepProps {
  phone: string;
  onDone: () => void;
}

export function RegisterStep({ phone, onDone }: RegisterStepProps) {
  const { register } = useAuth();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ firstName?: string; password?: string; form?: string }>({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const next: typeof errors = {};
    if (!firstName.trim()) next.firstName = "Ismingizni kiriting";
    if (password.length < MIN_PASSWORD) next.password = `Parol kamida ${MIN_PASSWORD} ta belgidan iborat bo'lsin`;
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      await register({
        phone,
        first_name: firstName.trim(),
        last_name: lastName.trim(),
        password,
      });
      onDone();
    } catch (err) {
      setErrors({ form: errorMessage(err, "Ro'yxatdan o'tib bo'lmadi. Qaytadan urinib ko'ring.") });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <h1 className="text-[26px] font-extrabold leading-tight tracking-tight text-ink">Ro&apos;yxatdan o&apos;tish</h1>
      <p className="mt-2 text-[15px] text-ink-muted">{formatPhone(phone)} raqami uchun yangi akkaunt</p>

      <div className="mt-8 space-y-4">
        <Field
          label="Ism"
          autoComplete="given-name"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
          error={errors.firstName}
        />
        <Field
          label="Familiya (ixtiyoriy)"
          autoComplete="family-name"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
        />
        <Field
          label="Parol"
          type="password"
          autoComplete="new-password"
          hint={`Kamida ${MIN_PASSWORD} ta belgi`}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={errors.password}
        />
      </div>

      {errors.form && (
        <p role="alert" className="mt-4 rounded-control bg-danger-tint px-4 py-3 text-sm font-medium text-danger">
          {errors.form}
        </p>
      )}

      <Button type="submit" fullWidth className="mt-8" loading={loading}>
        Ro&apos;yxatdan o&apos;tish
      </Button>
    </form>
  );
}
