"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { useAuth } from "@/contexts/AuthContext";
import { formatPhone } from "@/lib/format";
import { isApiError } from "@/lib/api";
import { errorMessage } from "@/lib/use-api";

interface PasswordStepProps {
  phone: string;
  onDone: () => void;
}

export function PasswordStep({ phone, onDone }: PasswordStepProps) {
  const { login } = useAuth();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) {
      setError("Parolni kiriting");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      await login({ phone, password });
      onDone();
    } catch (err) {
      setError(
        isApiError(err) && (err.status === 400 || err.status === 401)
          ? "Telefon raqami yoki parol noto'g'ri"
          : errorMessage(err)
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <h1 className="text-[26px] font-extrabold leading-tight tracking-tight text-ink">Parolni kiriting</h1>
      <p className="mt-2 text-[15px] text-ink-muted">{formatPhone(phone)} raqami uchun parol</p>

      <Field
        className="mt-8"
        label="Parol"
        type="password"
        autoComplete="current-password"
        value={password}
        onChange={(e) => {
          setPassword(e.target.value);
          setError(null);
        }}
        error={error}
        autoFocus
      />

      <Button type="submit" fullWidth className="mt-8" loading={loading} disabled={!password}>
        Kirish
      </Button>
    </form>
  );
}
