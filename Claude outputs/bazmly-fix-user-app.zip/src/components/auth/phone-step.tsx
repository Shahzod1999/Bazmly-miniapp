"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { useAuth } from "@/contexts/AuthContext";
import { digitsOnly, formatLocalPhone, toE164Uz } from "@/lib/format";
import { errorMessage } from "@/lib/use-api";

interface PhoneStepProps {
  onRegistered: (phone: string) => void;
  onNewUser: (phone: string) => void;
}

export function PhoneStep({ onRegistered, onNewUser }: PhoneStepProps) {
  const { checkPhone } = useAuth();
  const [digits, setDigits] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const isComplete = digits.length === 9;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isComplete) {
      setError("Telefon raqamini to'liq kiriting");
      return;
    }
    setError(null);
    setLoading(true);
    const phone = toE164Uz(digits);
    try {
      const result = await checkPhone(phone);
      if (!result.registered) {
        onNewUser(phone);
      } else if (result.password_required) {
        onRegistered(phone);
      } else {
        // Parolsiz akkaunt (Telegram orqali yaratilgan) — telefon orqali kirish imkoni yo'q
        setError("Bu raqam Telegram orqali ro'yxatdan o'tgan. Bazmly'ni Telegram ichida oching.");
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <h1 className="text-[26px] font-extrabold leading-tight tracking-tight text-ink">Telefon raqamingiz</h1>
      <p className="mt-2 text-[15px] text-ink-muted">Kirish yoki ro&apos;yxatdan o&apos;tish uchun raqamingizni kiriting.</p>

      <Field
        className="mt-8"
        label="Telefon raqami"
        prefix="+998"
        type="tel"
        inputMode="tel"
        autoComplete="tel-national"
        placeholder="90 123 45 67"
        value={formatLocalPhone(digits)}
        onChange={(e) => {
          const raw = digitsOnly(e.target.value);
          setDigits((raw.startsWith("998") && raw.length > 9 ? raw.slice(3) : raw).slice(0, 9));
          setError(null);
        }}
        error={error}
      />

      <Button type="submit" fullWidth className="mt-8" loading={loading} disabled={!isComplete}>
        Davom etish
      </Button>
    </form>
  );
}
