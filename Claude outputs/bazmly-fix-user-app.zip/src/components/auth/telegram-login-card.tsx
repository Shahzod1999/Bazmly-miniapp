"use client";

import React, { useState } from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { errorMessage } from "@/lib/use-api";

/** Telegram ichida, foydalanuvchi kirmagan holatda (chiqib ketgan yoki avtomatik kirish xato bergan) */
export function TelegramLoginCard() {
  const { loginWithTelegram, telegramError } = useAuth();
  const [error, setError] = useState<string | null>(telegramError);
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      await loginWithTelegram();
    } catch (err) {
      setError(errorMessage(err, "Telegram orqali kirib bo'lmadi"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
      <Image src="/logo.webp" alt="Bazmly" width={289} height={71} className="h-10 w-auto dark:brightness-0 dark:invert" />
      <h1 className="mt-8 text-2xl font-extrabold text-ink">Telegram orqali kirish</h1>
      <p className="mt-2 text-[15px] text-ink-muted">Bron qilish uchun Telegram akkauntingiz bilan kiring.</p>
      {error && (
        <p role="alert" className="mt-4 rounded-control bg-danger-tint px-4 py-3 text-sm font-medium text-danger">
          {error}
        </p>
      )}
      <Button fullWidth className="mt-8" onClick={handleLogin} loading={loading}>
        Kirish
      </Button>
    </div>
  );
}
