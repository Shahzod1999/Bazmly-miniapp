"use client";

import React from "react";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { LogIn } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { EmptyState } from "@/components/ui/state-views";
import { useAuth } from "@/contexts/AuthContext";

/** Faqat kirgan foydalanuvchi uchun sahifalar (bron, chiptalar, to'lov) */
export function RequireAuth({ children, title = "Bron qilish" }: { children: React.ReactNode; title?: string }) {
  const { user, loading } = useAuth();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  if (loading) return <div className="flex-1" />;
  if (user) return <>{children}</>;

  const query = searchParams.toString();
  const next = encodeURIComponent(`${pathname}${query ? `?${query}` : ""}`);
  return (
    <div className="flex-1">
      <PageHeader title={title} back />
      <EmptyState
        icon={<LogIn className="h-10 w-10" />}
        title="Akkauntga kiring"
        text="Davom etish uchun telefon raqamingiz yoki Telegram orqali kiring."
        action={
          <Link href={`/login?next=${next}`} className="flex h-12 items-center rounded-control bg-brand px-6 text-base font-bold text-on-brand">
            Kirish
          </Link>
        }
      />
    </div>
  );
}
