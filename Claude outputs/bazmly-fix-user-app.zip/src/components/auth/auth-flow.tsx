"use client";

import React, { useState } from "react";
import Image from "next/image";
import { useRouter, useSearchParams } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import { IconButton } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import { useTelegramBackButton } from "@/lib/telegram";
import { PhoneStep } from "./phone-step";
import { PasswordStep } from "./password-step";
import { RegisterStep } from "./register-step";

type Step = { name: "phone" } | { name: "password"; phone: string } | { name: "register"; phone: string };

/** Telefon raqami orqali kirish yoki ro'yxatdan o'tish */
export function AuthFlow() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const toast = useToast();
  const [step, setStep] = useState<Step>({ name: "phone" });

  const goBack = () => setStep({ name: "phone" });
  useTelegramBackButton(goBack, step.name !== "phone");

  const finish = (message: string) => {
    toast(message);
    // Kirishdan oldin ochilgan sahifaga qaytarish (faqat ilova ichidagi yo'llar)
    const next = searchParams.get("next");
    if (next && next.startsWith("/") && !next.startsWith("//")) router.replace(next);
  };

  return (
    <div className="flex flex-1 flex-col px-5 pt-[calc(var(--tg-safe-top)+16px)]">
      <div className="flex h-11 items-center">
        {step.name !== "phone" && (
          <IconButton label="Orqaga" onClick={goBack} className="-ml-2">
            <ChevronLeft className="h-6 w-6" />
          </IconButton>
        )}
      </div>

      <Image src="/logo.webp" alt="Bazmly" width={289} height={71} priority className="mt-4 h-9 w-auto self-start dark:brightness-0 dark:invert" />

      <div className="mt-8 flex-1">
        {step.name === "phone" && (
          <PhoneStep
            onRegistered={(phone) => setStep({ name: "password", phone })}
            onNewUser={(phone) => setStep({ name: "register", phone })}
          />
        )}
        {step.name === "password" && <PasswordStep phone={step.phone} onDone={() => finish("Xush kelibsiz!")} />}
        {step.name === "register" && (
          <RegisterStep phone={step.phone} onDone={() => finish("Ro'yxatdan muvaffaqiyatli o'tdingiz!")} />
        )}
      </div>
    </div>
  );
}
