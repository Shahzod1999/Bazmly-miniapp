"use client";

import React, { useState } from "react";
import { Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import { useAuth } from "@/contexts/AuthContext";
import { requestTelegramContact, useIsTelegram } from "@/lib/telegram";
import { errorMessage } from "@/lib/use-api";

/** Telegram orqali kirgan va telefon raqami bog'lanmagan foydalanuvchiga kontakt ulashishni taklif qiladi */
export function SharePhoneBanner() {
  const { user, shareTelegramContact } = useAuth();
  const isTelegram = useIsTelegram();
  const toast = useToast();
  const [loading, setLoading] = useState(false);

  if (!user || user.phone || !isTelegram) return null;

  const handleShare = async () => {
    setLoading(true);
    try {
      const contact = await requestTelegramContact();
      if (!contact) return;
      await shareTelegramContact(contact);
      toast("Telefon raqami ulandi");
    } catch (err) {
      toast(errorMessage(err), "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-card border border-border bg-brand-tint p-4">
      <div className="flex items-start gap-3">
        <Phone className="mt-0.5 h-5 w-5 shrink-0 text-brand-strong" aria-hidden="true" />
        <div>
          <p className="font-bold text-ink">Telefon raqamingizni ulashing</p>
          <p className="mt-1 text-sm text-ink-muted">Muassasa bron bo&apos;yicha siz bilan bog&apos;lanishi uchun kerak.</p>
        </div>
      </div>
      <Button size="md" fullWidth className="mt-3" onClick={handleShare} loading={loading}>
        Raqamni ulashish
      </Button>
    </div>
  );
}
