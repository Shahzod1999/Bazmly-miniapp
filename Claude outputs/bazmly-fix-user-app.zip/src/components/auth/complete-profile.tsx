"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { useAuth } from "@/contexts/AuthContext";
import { errorMessage } from "@/lib/use-api";

/** Telegram orqali kirgan, lekin profili to'liq bo'lmagan foydalanuvchi uchun */
export function CompleteProfile() {
  const { user, completeProfile } = useAuth();
  const [firstName, setFirstName] = useState(user?.first_name ?? "");
  const [lastName, setLastName] = useState(user?.last_name ?? "");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim()) {
      setError("Ismingizni kiriting");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await completeProfile({ first_name: firstName.trim(), last_name: lastName.trim() });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-1 flex-col px-5 pt-[calc(var(--tg-safe-top)+40px)]">
      <h1 className="text-[26px] font-extrabold leading-tight tracking-tight text-ink">Tanishib olaylik</h1>
      <p className="mt-2 text-[15px] text-ink-muted">Bron qilishda muassasa sizni shu ism bilan ko&apos;radi.</p>
      <div className="mt-8 space-y-4">
        <Field label="Ism" autoComplete="given-name" value={firstName} onChange={(e) => setFirstName(e.target.value)} error={error} />
        <Field label="Familiya (ixtiyoriy)" autoComplete="family-name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
      </div>
      <Button type="submit" fullWidth className="mt-8" loading={loading}>
        Saqlash
      </Button>
    </form>
  );
}
