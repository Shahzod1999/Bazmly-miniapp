import React from "react";
import { RotateCw, WifiOff } from "lucide-react";
import { Button } from "./button";

export function Skeleton({ className = "" }: { className?: string }) {
  return <div aria-hidden="true" className={`skeleton rounded-xl ${className}`} />;
}

/** Sahifa yuklanayotganini ekran o'quvchiga bildiradi */
export function LoadingBlock({ label = "Yuklanmoqda", children }: { label?: string; children: React.ReactNode }) {
  return (
    <div role="status" aria-live="polite">
      <span className="sr-only">{label}</span>
      {children}
    </div>
  );
}

interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  text?: string;
  action?: React.ReactNode;
}

export function EmptyState({ icon, title, text, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center px-6 py-12 text-center">
      <div className="mb-5 flex h-24 w-24 items-center justify-center rounded-full bg-brand-tint text-brand-strong" aria-hidden="true">
        {icon}
      </div>
      <h2 className="text-lg font-bold text-ink">{title}</h2>
      {text && <p className="mt-2 max-w-xs text-[15px] leading-relaxed text-ink-muted">{text}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

interface ErrorStateProps {
  message?: string;
  onRetry?: () => void;
}

export function ErrorState({ message, onRetry }: ErrorStateProps) {
  return (
    <div role="alert">
      <EmptyState
        icon={<WifiOff className="h-10 w-10" />}
        title="Ma'lumotni yuklab bo'lmadi"
        text={message || "Internet aloqasini tekshiring va qaytadan urinib ko'ring."}
        action={
          onRetry && (
            <Button size="md" onClick={onRetry}>
              <RotateCw className="h-5 w-5" aria-hidden="true" />
              Qayta urinish
            </Button>
          )
        }
      />
    </div>
  );
}
