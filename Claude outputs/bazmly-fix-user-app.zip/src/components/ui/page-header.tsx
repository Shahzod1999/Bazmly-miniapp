"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import { IconButton } from "./button";
import { useIsTelegram, useTelegramBackButton } from "@/lib/telegram";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  /** Orqaga tugmasi (Telegram ichida tizim tugmasi ishlatiladi) */
  back?: boolean | (() => void);
  right?: React.ReactNode;
}

export function PageHeader({ title, subtitle, back = false, right }: PageHeaderProps) {
  const router = useRouter();
  const isTelegram = useIsTelegram();
  const handleBack = typeof back === "function" ? back : () => router.back();
  useTelegramBackButton(handleBack, Boolean(back));

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-surface-100 pt-[var(--tg-safe-top)]">
      <div className="flex h-14 items-center gap-1 px-2">
        {back && !isTelegram ? (
          <IconButton label="Orqaga" onClick={handleBack}>
            <ChevronLeft className="h-6 w-6" />
          </IconButton>
        ) : (
          <div className="w-11" aria-hidden="true" />
        )}
        <div className="min-w-0 flex-1 text-center">
          <h1 className="truncate text-[17px] font-bold leading-[22px] text-ink">{title}</h1>
          {subtitle && <p className="truncate text-xs font-medium text-ink-muted">{subtitle}</p>}
        </div>
        {right ?? <div className="w-11" aria-hidden="true" />}
      </div>
    </header>
  );
}
