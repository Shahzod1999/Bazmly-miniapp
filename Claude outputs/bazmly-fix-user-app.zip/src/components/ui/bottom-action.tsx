"use client";

import React from "react";
import { useMainButton } from "@/lib/telegram";
import { Button } from "./button";

interface BottomActionProps {
  text: string;
  onClick: () => void;
  disabled?: boolean;
  loading?: boolean;
  /** Tugma ustida ko'rsatiladigan qo'shimcha ma'lumot (jami summa va h.k.) */
  summary?: React.ReactNode;
}

/**
 * Sahifaning asosiy harakati. Telegram ichida tizim MainButton'i ishlatiladi,
 * oddiy brauzerda esa pastga yopishgan panel ko'rsatiladi.
 */
export function BottomAction({ text, onClick, disabled = false, loading = false, summary }: BottomActionProps) {
  const usesMainButton = useMainButton({ text, onClick, disabled, loading });

  if (usesMainButton) {
    return summary ? (
      <div className="pb-safe fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md border-t border-border bg-surface-100 px-4 pt-3">
        {summary}
      </div>
    ) : null;
  }

  return (
    <div className="pb-safe fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md rounded-t-sheet bg-surface-100 px-4 pt-3 shadow-[0_-4px_24px_rgba(0,0,0,0.08)]">
      {summary && <div className="mb-3">{summary}</div>}
      <Button fullWidth onClick={onClick} disabled={disabled} loading={loading}>
        {text}
      </Button>
    </div>
  );
}

/** BottomAction ostida kontent yopilib qolmasligi uchun bo'sh joy */
export function BottomActionSpacer({ withSummary = false }: { withSummary?: boolean }) {
  return <div aria-hidden="true" className={withSummary ? "h-40" : "h-28"} />;
}
