"use client";

import React, { useEffect, useId } from "react";
import { X } from "lucide-react";
import { IconButton } from "./button";
import { useSuspendMainButton, useTelegramBackButton } from "@/lib/telegram";

interface SheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
}

/** Pastdan chiqadigan oyna (bottom sheet). Escape va Telegram "Orqaga" bilan yopiladi. */
export function Sheet({ open, onClose, title, children, footer }: SheetProps) {
  const titleId = useId();
  useTelegramBackButton(onClose, open);
  useSuspendMainButton(open);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] mx-auto max-w-md">
      <button
        type="button"
        aria-label="Yopish"
        tabIndex={-1}
        onClick={onClose}
        className="animate-fade-in absolute inset-0 h-full w-full bg-black/50"
      />
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className="animate-sheet-up absolute inset-x-0 bottom-0 flex max-h-[90%] flex-col rounded-t-sheet bg-surface-100 shadow-[0_-4px_24px_rgba(0,0,0,0.12)]"
      >
        <div className="shrink-0 px-4 pt-2">
          <div className="mx-auto h-1 w-9 rounded-full bg-border" aria-hidden="true" />
          <div className="mt-2 flex items-center justify-between gap-2">
            <h2 id={titleId} className="text-xl font-bold text-ink">
              {title}
            </h2>
            <IconButton label="Yopish" onClick={onClose} className="-mr-2">
              <X className="h-5 w-5" />
            </IconButton>
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4">{children}</div>
        {footer && <div className="pb-safe shrink-0 px-4 pt-3">{footer}</div>}
      </section>
    </div>
  );
}
