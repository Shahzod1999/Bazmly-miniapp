"use client";

import React from "react";
import { Sheet } from "./sheet";
import { Button } from "./button";

interface ConfirmSheetProps {
  open: boolean;
  title: string;
  text: string;
  confirmText: string;
  cancelText?: string;
  onConfirm: () => void;
  onClose: () => void;
  loading?: boolean;
  danger?: boolean;
}

export function ConfirmSheet({ open, title, text, confirmText, cancelText = "Bekor qilish", onConfirm, onClose, loading, danger }: ConfirmSheetProps) {
  return (
    <Sheet
      open={open}
      onClose={onClose}
      title={title}
      footer={
        <div className="flex gap-3">
          <Button variant="secondary" fullWidth onClick={onClose} disabled={loading}>
            {cancelText}
          </Button>
          <Button variant={danger ? "danger" : "primary"} fullWidth onClick={onConfirm} loading={loading}>
            {confirmText}
          </Button>
        </div>
      }
    >
      <p className="pt-1 text-[15px] leading-relaxed text-ink-muted">{text}</p>
    </Sheet>
  );
}
