import React from "react";
import { Loader2 } from "lucide-react";

type Variant = "primary" | "secondary" | "ghost" | "danger";
type Size = "md" | "lg";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  fullWidth?: boolean;
}

const VARIANTS: Record<Variant, string> = {
  primary: "bg-brand text-on-brand active:bg-brand-strong disabled:opacity-50",
  secondary: "bg-surface-200 text-ink active:opacity-80 disabled:opacity-50",
  ghost: "bg-transparent text-brand-strong active:bg-brand-tint disabled:opacity-50",
  danger: "bg-danger-tint text-danger active:opacity-80 disabled:opacity-50",
};

const SIZES: Record<Size, string> = {
  md: "h-12 px-5 text-[15px]",
  lg: "h-14 px-6 text-[17px]",
};

export function Button({
  variant = "primary",
  size = "lg",
  loading = false,
  fullWidth = false,
  disabled,
  className = "",
  children,
  type = "button",
  ...rest
}: ButtonProps) {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={`inline-flex items-center justify-center gap-2 rounded-control font-bold transition-colors disabled:cursor-not-allowed ${VARIANTS[variant]} ${SIZES[size]} ${fullWidth ? "w-full" : ""} ${className}`}
      {...rest}
    >
      {loading && <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />}
      {children}
    </button>
  );
}

interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  tone?: "plain" | "overlay";
}

/** 44×44 ikonali tugma; `label` ekran o'quvchi uchun majburiy */
export function IconButton({ label, tone = "plain", className = "", children, type = "button", ...rest }: IconButtonProps) {
  const toneClass =
    tone === "overlay" ? "bg-black/45 text-white backdrop-blur-md" : "bg-transparent text-ink active:bg-surface-200";
  return (
    <button
      type={type}
      aria-label={label}
      className={`inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors ${toneClass} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}
