"use client";

import Image from "next/image";
import { useAuth } from "@/contexts/AuthContext";

/** Sessiya tiklanayotgan paytda (token yoki Telegram orqali kirish) ko'rsatiladi. */
export default function SplashScreen() {
  const { loading } = useAuth();
  if (!loading) return null;

  return (
    <div
      role="status"
      aria-label="Ilova yuklanmoqda"
      className="fixed inset-0 z-[9999] mx-auto flex max-w-md items-center justify-center bg-brand"
    >
      <Image
        src="/logo-loading.webp"
        alt="Bazmly"
        width={91}
        height={99}
        priority
        className="h-24 w-auto animate-pulse object-contain"
      />
    </div>
  );
}
