"use client";

import React from "react";
import { Minus, Plus } from "lucide-react";
import { parseISODate, weekdayShort } from "@/lib/format";
import { hapticSelection } from "@/lib/telegram";

const CHIP_BASE = "flex shrink-0 flex-col items-center justify-center rounded-card font-semibold transition-colors";

interface DatePickerProps {
  dates: string[];
  value: string | null;
  onChange: (date: string) => void;
  disabledDates?: Set<string>;
}

/** Gorizontal sana tanlash (YYYY-MM-DD) */
export function DatePicker({ dates, value, onChange, disabledDates }: DatePickerProps) {
  return (
    <div role="radiogroup" aria-label="Sana" className="scrollbar-none -mx-4 flex gap-2 overflow-x-auto px-4">
      {dates.map((iso) => {
        const date = parseISODate(iso);
        const active = iso === value;
        const disabled = disabledDates?.has(iso) ?? false;
        return (
          <button
            key={iso}
            type="button"
            role="radio"
            aria-checked={active}
            aria-label={`${date.getDate()}-sana${disabled ? ", band" : ""}`}
            disabled={disabled}
            onClick={() => {
              onChange(iso);
              hapticSelection();
            }}
            className={`${CHIP_BASE} h-[72px] w-14 ${
              active ? "bg-brand-strong text-on-brand" : disabled ? "bg-surface-200 text-ink-muted line-through opacity-60" : "bg-surface-100 text-ink"
            }`}
          >
            <span className="text-xs">{weekdayShort(date)}</span>
            <span className="text-xl font-extrabold">{date.getDate()}</span>
          </button>
        );
      })}
    </div>
  );
}

interface TimePickerProps {
  times: string[];
  value: string | null;
  onChange: (time: string) => void;
}

export function TimePicker({ times, value, onChange }: TimePickerProps) {
  if (times.length === 0) {
    return <p className="rounded-card bg-surface-200 px-4 py-3 text-sm text-ink-muted">Bu kuni bo&apos;sh vaqt yo&apos;q</p>;
  }
  return (
    <div role="radiogroup" aria-label="Vaqt" className="grid grid-cols-4 gap-2">
      {times.map((time) => {
        const active = time === value;
        return (
          <button
            key={time}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => {
              onChange(time);
              hapticSelection();
            }}
            className={`h-11 rounded-control text-[15px] font-semibold tabular-nums ${
              active ? "bg-brand-strong text-on-brand" : "bg-surface-100 text-ink"
            }`}
          >
            {time}
          </button>
        );
      })}
    </div>
  );
}

interface CounterProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  hint?: string;
}

/** Mehmonlar soni kabi raqamli qiymat uchun +/- boshqaruv */
export function Counter({ label, value, onChange, min = 1, max = 2000, step = 1, hint }: CounterProps) {
  const set = (next: number) => {
    const clamped = Math.max(min, Math.min(max, next));
    if (clamped !== value) {
      onChange(clamped);
      hapticSelection();
    }
  };
  return (
    <div className="flex items-center gap-3 rounded-card bg-surface-100 p-3 pl-4 shadow-[0_2px_12px_rgba(28,20,16,0.06)]">
      <div className="min-w-0 flex-1">
        <p className="font-bold text-ink">{label}</p>
        {hint && <p className="text-xs text-ink-muted">{hint}</p>}
      </div>
      <button type="button" onClick={() => set(value - step)} disabled={value <= min} aria-label={`${label}: kamaytirish`} className="flex h-11 w-11 items-center justify-center rounded-control bg-surface-200 text-ink disabled:opacity-40">
        <Minus className="h-5 w-5" aria-hidden="true" />
      </button>
      <input
        type="number"
        inputMode="numeric"
        aria-label={label}
        min={min}
        max={max}
        value={value}
        onChange={(e) => {
          const n = parseInt(e.target.value, 10);
          if (Number.isFinite(n)) onChange(Math.max(min, Math.min(max, n)));
        }}
        className="h-11 w-16 rounded-control border border-border bg-transparent text-center text-lg font-bold tabular-nums text-ink outline-none focus:border-brand [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
      />
      <button type="button" onClick={() => set(value + step)} disabled={value >= max} aria-label={`${label}: ko'paytirish`} className="flex h-11 w-11 items-center justify-center rounded-control bg-surface-200 text-ink disabled:opacity-40">
        <Plus className="h-5 w-5" aria-hidden="true" />
      </button>
    </div>
  );
}

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="mb-3 mt-6 text-base font-bold text-ink">{children}</h2>;
}
