"use client";

import React from "react";
import { Field } from "@/components/ui/field";
import { digitsOnly, formatLocalPhone } from "@/lib/format";

export interface ContactValue {
  name: string;
  /** +998 dan keyingi 9 ta raqam */
  phoneDigits: string;
  note: string;
}

export function contactFromUser(user: { first_name: string; last_name: string; phone: string | null } | null): ContactValue {
  const phone = digitsOnly(user?.phone ?? "");
  return {
    name: user ? `${user.first_name} ${user.last_name}`.trim() : "",
    phoneDigits: phone.startsWith("998") ? phone.slice(3) : phone,
    note: "",
  };
}

export function contactErrors(value: ContactValue): { name?: string; phone?: string } {
  const errors: { name?: string; phone?: string } = {};
  if (!value.name.trim()) errors.name = "Ismingizni kiriting";
  if (value.phoneDigits.length !== 9) errors.phone = "Telefon raqamini to'liq kiriting";
  return errors;
}

interface ContactFieldsProps {
  value: ContactValue;
  onChange: (value: ContactValue) => void;
  errors?: { name?: string; phone?: string };
}

export function ContactFields({ value, onChange, errors }: ContactFieldsProps) {
  return (
    <div className="space-y-4">
      <Field label="Ism" autoComplete="name" value={value.name} onChange={(e) => onChange({ ...value, name: e.target.value })} error={errors?.name} />
      <Field
        label="Telefon raqami"
        prefix="+998"
        type="tel"
        inputMode="tel"
        autoComplete="tel-national"
        placeholder="90 123 45 67"
        value={formatLocalPhone(value.phoneDigits)}
        onChange={(e) => onChange({ ...value, phoneDigits: digitsOnly(e.target.value).slice(0, 9) })}
        error={errors?.phone}
      />
      <div>
        <label htmlFor="booking-note" className="mb-1.5 block text-sm font-semibold text-ink">
          Izoh (ixtiyoriy)
        </label>
        <textarea
          id="booking-note"
          rows={3}
          maxLength={500}
          value={value.note}
          onChange={(e) => onChange({ ...value, note: e.target.value })}
          placeholder="Masalan: tug'ilgan kun, deraza yonidagi stol"
          className="w-full rounded-control border border-border bg-surface-100 px-4 py-3 text-base text-ink outline-none placeholder:text-ink-muted focus:border-brand"
        />
      </div>
    </div>
  );
}
