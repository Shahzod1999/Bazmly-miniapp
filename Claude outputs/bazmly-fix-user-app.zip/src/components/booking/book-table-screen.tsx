"use client";

import React, { useMemo, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { Armchair } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { BottomAction, BottomActionSpacer } from "@/components/ui/bottom-action";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { useToast } from "@/components/ui/toast";
import { Counter, DatePicker, SectionTitle, TimePicker } from "@/components/booking/pickers";
import { ContactFields, contactErrors, contactFromUser, type ContactValue } from "@/components/booking/contact-fields";
import { cartSummary, decodeCart } from "@/components/venue/venue-menu";
import { useAuth } from "@/contexts/AuthContext";
import { bookingService, venueService } from "@/lib/api";
import { upcomingDates, timeSlots } from "@/lib/booking";
import { addMinutes, formatSom, toApiTime, toE164Uz } from "@/lib/format";
import { hapticNotify, hapticSelection } from "@/lib/telegram";
import { errorMessage, useApiQuery } from "@/lib/use-api";
import { RequireAuth } from "@/components/auth/require-auth";

const DURATION_MIN = 120;

export function BookTableScreen() {
  return (
    <RequireAuth>
      <BookTableForm />
    </RequireAuth>
  );
}

function BookTableForm() {
  const { id } = useParams<{ id: string }>();
  const venueId = Number(id);
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user } = useAuth();
  const toast = useToast();

  const cart = useMemo(() => decodeCart(searchParams.get("items")), [searchParams]);
  const [now] = useState(() => new Date());
  const [allDates] = useState(() => upcomingDates(21));
  const [guests, setGuests] = useState(2);
  const [date, setDate] = useState<string | null>(null);
  const [time, setTime] = useState<string | null>(null);
  const [tableId, setTableId] = useState<number | null>(null);
  const [contact, setContact] = useState<ContactValue>(() => contactFromUser(user));
  const [showErrors, setShowErrors] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const detail = useApiQuery(`venue:${venueId}`, () => venueService.getVenueDetail(venueId));
  const menu = useApiQuery(Object.keys(cart).length ? `menu:${venueId}` : null, () => venueService.getMenu(venueId));

  const venue = detail.state.status === "success" ? detail.state.data.venue : null;
  const dates = venue ? allDates.slice(Math.max(0, venue.min_advance_booking_days)) : [];
  const times = date && detail.state.status === "success" ? timeSlots(date, detail.state.data.working_hours, DURATION_MIN, now) : [];
  const endTime = time ? addMinutes(time, DURATION_MIN) : null;

  const tablesKey = date && time ? `tables:${venueId}:${date}:${time}:${guests}` : null;
  const tables = useApiQuery(tablesKey, () =>
    venueService.getFreeTables(venueId, date as string, toApiTime(time as string), toApiTime(endTime as string), guests)
  );
  const zones = useApiQuery(`zones:${venueId}`, () => venueService.getZones(venueId));
  const zoneName = (zoneId: number | null) =>
    zones.state.status === "success" ? zones.state.data.find((z) => z.id === zoneId)?.name : undefined;

  const items = menu.state.status === "success" ? menu.state.data : [];
  const preorder = cartSummary(cart, items);
  const errors = contactErrors(contact);

  const submit = async () => {
    setShowErrors(true);
    if (!date || !time || !endTime || !tableId) {
      toast("Sana, vaqt va stolni tanlang", "error");
      return;
    }
    if (Object.keys(errors).length > 0) return;
    setSubmitting(true);
    setSubmitError(null);
    try {
      const result = await bookingService.bookTable({
        venue_id: venueId,
        booking_date: date,
        start_time: toApiTime(time),
        end_time: toApiTime(endTime),
        guests_count: guests,
        table_id: tableId,
        contact_name: contact.name.trim(),
        contact_phone: toE164Uz(contact.phoneDigits),
        note: contact.note.trim() || null,
        items: Object.entries(cart).map(([menuItemId, quantity]) => ({ menu_item_id: Number(menuItemId), quantity })),
      });
      hapticNotify("success");
      router.replace(`/payment/${result.booking.id}`);
    } catch (err) {
      hapticNotify("error");
      setSubmitError(errorMessage(err, "Bron qilib bo'lmadi. Qaytadan urinib ko'ring."));
      setSubmitting(false);
    }
  };

  if (detail.state.status === "loading") {
    return (
      <>
        <PageHeader title="Stol bron qilish" back />
        <LoadingBlock>
          <div className="space-y-4 p-4">
            <Skeleton className="h-16" />
            <Skeleton className="h-20" />
            <Skeleton className="h-32" />
          </div>
        </LoadingBlock>
      </>
    );
  }
  if (detail.state.status === "error") {
    return (
      <>
        <PageHeader title="Stol bron qilish" back />
        <ErrorState message={detail.state.error.message} onRetry={detail.retry} />
      </>
    );
  }

  return (
    <div className="flex-1">
      <PageHeader title="Stol bron qilish" subtitle={venue?.name} back />
      <div className="px-4 pt-4">
        <Counter label="Mehmonlar soni" value={guests} onChange={(v) => { setGuests(v); setTableId(null); }} min={1} max={venue?.total_seats || 50} />

        <SectionTitle>Sana</SectionTitle>
        <DatePicker dates={dates} value={date} onChange={(d) => { setDate(d); setTime(null); setTableId(null); }} />

        {date && (
          <>
            <SectionTitle>Vaqt (2 soat)</SectionTitle>
            <TimePicker times={times} value={time} onChange={(t) => { setTime(t); setTableId(null); }} />
          </>
        )}

        {tablesKey && (
          <>
            <SectionTitle>Stol</SectionTitle>
            {tables.state.status === "loading" && (
              <LoadingBlock label="Bo'sh stollar qidirilmoqda">
                <div className="grid grid-cols-3 gap-2">
                  {[0, 1, 2].map((i) => <Skeleton key={i} className="h-16" />)}
                </div>
              </LoadingBlock>
            )}
            {tables.state.status === "error" && <ErrorState message={tables.state.error.message} onRetry={tables.retry} />}
            {tables.state.status === "success" && tables.state.data.length === 0 && (
              <EmptyState icon={<Armchair className="h-10 w-10" />} title="Bo'sh stol yo'q" text="Boshqa vaqt yoki sanani tanlab ko'ring." />
            )}
            {tables.state.status === "success" && tables.state.data.length > 0 && (
              <div role="radiogroup" aria-label="Stol" className="grid grid-cols-3 gap-2">
                {tables.state.data.map((table) => {
                  const active = table.id === tableId;
                  return (
                    <button
                      key={table.id}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      onClick={() => { setTableId(table.id); hapticSelection(); }}
                      className={`flex h-16 flex-col items-center justify-center rounded-card text-sm font-semibold ${
                        active ? "bg-brand-strong text-on-brand" : "bg-surface-100 text-ink"
                      }`}
                    >
                      <span className="text-base font-extrabold">{table.number}-stol</span>
                      <span className={active ? "" : "text-ink-muted"}>
                        {table.seats} o&apos;rin{zoneName(table.zone_id) ? ` · ${zoneName(table.zone_id)}` : ""}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </>
        )}

        {preorder.count > 0 && (
          <>
            <SectionTitle>Oldindan buyurtma</SectionTitle>
            <ul className="divide-y divide-border rounded-card bg-surface-100 px-4">
              {Object.entries(cart).map(([itemId, qty]) => {
                const item = items.find((i) => i.id === Number(itemId));
                return (
                  <li key={itemId} className="flex justify-between gap-3 py-3 text-[15px]">
                    <span className="text-ink">{item?.name ?? "Taom"} × {qty}</span>
                    <span className="font-semibold text-ink">{formatSom(qty * Number(item?.effective_price ?? 0))}</span>
                  </li>
                );
              })}
            </ul>
          </>
        )}

        <SectionTitle>Aloqa ma&apos;lumotlari</SectionTitle>
        <ContactFields value={contact} onChange={setContact} errors={showErrors ? errors : undefined} />

        {submitError && (
          <p role="alert" className="mt-4 rounded-control bg-danger-tint px-4 py-3 text-sm font-medium text-danger">
            {submitError}
          </p>
        )}
      </div>

      <BottomActionSpacer withSummary={preorder.count > 0} />
      <BottomAction
        text={submitError ? "Qayta urinish" : "Bron qilish"}
        onClick={submit}
        loading={submitting}
        disabled={!date || !time || !tableId}
        summary={
          preorder.count > 0 ? (
            <p className="flex justify-between text-[15px]">
              <span className="text-ink-muted">Oldindan buyurtma</span>
              <span className="font-extrabold text-ink">{formatSom(preorder.total)}</span>
            </p>
          ) : undefined
        }
      />
    </div>
  );
}
