import React from "react";
import { bookingStatus } from "@/lib/booking";

const TONES = {
  success: "bg-success-tint text-success",
  warning: "bg-brand-tint text-brand-strong",
  danger: "bg-danger-tint text-danger",
  muted: "bg-surface-200 text-ink-muted",
} as const;

export function StatusBadge({ status }: { status: string }) {
  const { label, tone } = bookingStatus(status);
  return <span className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ${TONES[tone]}`}>{label}</span>;
}
