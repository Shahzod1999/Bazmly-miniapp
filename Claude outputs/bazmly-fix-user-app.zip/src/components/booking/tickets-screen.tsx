"use client";

import React, { useState } from "react";
import Link from "next/link";
import { CalendarDays, ChevronRight, Ticket } from "lucide-react";
import { Sheet } from "@/components/ui/sheet";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { RequireAuth } from "@/components/auth/require-auth";
import { BookingTicket } from "./booking-ticket";
import { ReviewForm } from "./review-form";
import { StatusBadge } from "./status-badge";
import { bookingService, type BookingListItem } from "@/lib/api";
import { formatDate, formatSom, formatTime } from "@/lib/format";
import { useApiQuery } from "@/lib/use-api";

const ACTIVE = new Set(["pending", "confirmed", "checked_in"]);

export function TicketsScreen() {
  return (
    <RequireAuth title="Chiptalar">
      <Tickets />
    </RequireAuth>
  );
}

function Tickets() {
  const [tab, setTab] = useState<"active" | "history">("active");
  const [openId, setOpenId] = useState<number | null>(null);
  const list = useApiQuery("my-bookings", () => bookingService.getMyBookings());
  const { state } = list;

  const items =
    state.status === "success"
      ? state.data
          .filter((b) => (tab === "active" ? ACTIVE.has(b.status) : !ACTIVE.has(b.status)))
          .sort((a, b) => (tab === "active" ? a.booking_date.localeCompare(b.booking_date) : b.booking_date.localeCompare(a.booking_date)))
      : [];

  return (
    <div className="flex-1 px-4 pt-[calc(var(--tg-safe-top)+16px)]">
      <h1 className="text-[22px] font-extrabold tracking-tight text-ink">Chiptalar</h1>

      <div role="tablist" aria-label="Bronlar" className="mt-4 grid grid-cols-2 rounded-control bg-surface-200 p-1">
        {(["active", "history"] as const).map((value) => (
          <button
            key={value}
            type="button"
            role="tab"
            aria-selected={tab === value}
            onClick={() => setTab(value)}
            className={`h-11 rounded-[10px] text-[15px] font-semibold ${tab === value ? "bg-surface-100 text-ink shadow-sm" : "text-ink-muted"}`}
          >
            {value === "active" ? "Faol" : "Tarix"}
          </button>
        ))}
      </div>

      <div className="mt-4 pb-6">
        {state.status === "loading" && (
          <LoadingBlock label="Bronlar yuklanmoqda">
            <div className="space-y-3">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
          </LoadingBlock>
        )}
        {state.status === "error" && <ErrorState message={state.error.message} onRetry={list.retry} />}
        {state.status === "success" && items.length === 0 && (
          <EmptyState
            icon={<Ticket className="h-10 w-10" />}
            title={tab === "active" ? "Faol bronlar yo'q" : "Tarix bo'sh"}
            text={tab === "active" ? "Restoran yoki to'yxonani bron qilsangiz, chiptangiz shu yerda chiqadi." : undefined}
            action={
              tab === "active" && (
                <Link href="/" className="flex h-12 items-center rounded-control bg-brand px-6 text-base font-bold text-on-brand">
                  Joy tanlash
                </Link>
              )
            }
          />
        )}
        {state.status === "success" && items.length > 0 && (
          <ul className="space-y-3">
            {items.map((booking) => (
              <li key={booking.id}>
                <BookingRow booking={booking} onOpen={() => setOpenId(booking.id)} />
              </li>
            ))}
          </ul>
        )}
      </div>

      <TicketSheet
        bookingId={openId}
        onClose={() => setOpenId(null)}
        onStatusChange={(id, status) => list.setData((prev) => prev.map((b) => (b.id === id ? { ...b, status } : b)))}
      />
    </div>
  );
}

function BookingRow({ booking, onOpen }: { booking: BookingListItem; onOpen: () => void }) {
  return (
    <button type="button" onClick={onOpen} className="flex w-full items-center gap-3 rounded-card bg-surface-100 p-4 text-left shadow-[0_2px_12px_rgba(28,20,16,0.06)]">
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-base font-bold text-ink">{booking.venue_name}</p>
          <StatusBadge status={booking.status} />
        </div>
        <p className="mt-1.5 flex items-center gap-1.5 text-sm text-ink-muted">
          <CalendarDays className="h-4 w-4" aria-hidden="true" />
          {formatDate(booking.booking_date)} · {formatTime(booking.start_time)}
        </p>
        <p className="mt-1 text-sm text-ink-muted">
          {booking.guests_count} kishi
          {booking.table_number ? ` · ${booking.table_number}-stol` : booking.kind === "hall" ? " · zal" : ""}
          {Number(booking.total_amount) > 0 ? ` · ${formatSom(booking.total_amount)}` : ""}
        </p>
      </div>
      <ChevronRight className="h-5 w-5 shrink-0 text-ink-muted" aria-hidden="true" />
    </button>
  );
}

function TicketSheet({
  bookingId,
  onClose,
  onStatusChange,
}: {
  bookingId: number | null;
  onClose: () => void;
  onStatusChange: (id: number, status: BookingListItem["status"]) => void;
}) {
  const detail = useApiQuery(bookingId ? `booking:${bookingId}` : null, () => bookingService.getBookingDetail(bookingId as number));
  const { state } = detail;

  return (
    <Sheet open={bookingId !== null} onClose={onClose} title="Chipta">
      {state.status === "loading" && (
        <LoadingBlock>
          <Skeleton className="h-96" />
        </LoadingBlock>
      )}
      {state.status === "error" && <ErrorState message={state.error.message} onRetry={detail.retry} />}
      {state.status === "success" && (
        <div className="space-y-4">
          <BookingTicket
            detail={state.data}
            onChanged={(next) => {
              detail.setData(() => next);
              onStatusChange(next.booking.id, next.booking.status);
            }}
          />
          {state.data.booking.status === "completed" && <ReviewForm bookingId={state.data.booking.id} />}
        </div>
      )}
    </Sheet>
  );
}
