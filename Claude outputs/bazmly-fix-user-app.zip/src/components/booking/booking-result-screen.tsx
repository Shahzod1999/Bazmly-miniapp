"use client";

import React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { Ticket } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { RequireAuth } from "@/components/auth/require-auth";
import { BookingTicket } from "./booking-ticket";
import { bookingService, isApiError } from "@/lib/api";
import { useApiQuery } from "@/lib/use-api";

export function BookingResultScreen() {
  return (
    <RequireAuth title="Bron">
      <BookingResult />
    </RequireAuth>
  );
}

function BookingResult() {
  const { id } = useParams<{ id: string }>();
  const bookingId = Number(id);
  const query = useApiQuery(Number.isInteger(bookingId) ? `booking:${bookingId}` : null, () => bookingService.getBookingDetail(bookingId));
  const { state } = query;

  return (
    <div className="flex-1">
      <PageHeader title="Bron" back />
      <div className="px-4 pb-8 pt-4">
        {state.status === "loading" && (
          <LoadingBlock label="Bron ma'lumotlari yuklanmoqda">
            <Skeleton className="h-96" />
          </LoadingBlock>
        )}
        {state.status === "error" &&
          (isApiError(state.error) && (state.error.status === 404 || state.error.status === 403) ? (
            <EmptyState icon={<Ticket className="h-10 w-10" />} title="Bron topilmadi" text="Bu bron mavjud emas yoki sizga tegishli emas." />
          ) : (
            <ErrorState message={state.error.message} onRetry={query.retry} />
          ))}
        {state.status === "success" && (
          <>
            {state.data.booking.status === "pending" && (
              <div className="mb-4 text-center">
                <h1 className="text-2xl font-extrabold text-ink">Bron yuborildi</h1>
                <p className="mt-1 text-[15px] text-ink-muted">Muassasa tasdiqlagach sizga xabarnoma keladi.</p>
              </div>
            )}
            <BookingTicket detail={state.data} onChanged={(next) => query.setData(() => next)} />
            <div className="mt-4 grid grid-cols-2 gap-3">
              <Link href="/tickets" className="flex h-12 items-center justify-center rounded-control bg-surface-200 font-semibold text-ink">
                Chiptalarim
              </Link>
              <Link href="/" className="flex h-12 items-center justify-center rounded-control bg-surface-200 font-semibold text-ink">
                Bosh sahifa
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
