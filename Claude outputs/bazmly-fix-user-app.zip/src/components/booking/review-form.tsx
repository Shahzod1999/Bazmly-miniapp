"use client";

import React, { useState } from "react";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import { venueService } from "@/lib/api";
import { errorMessage } from "@/lib/use-api";

/** Yakunlangan bron uchun baho va sharh qoldirish */
export function ReviewForm({ bookingId }: { bookingId: number }) {
  const toast = useToast();
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  if (sent) {
    return <p className="rounded-control bg-success-tint px-4 py-3 text-sm font-semibold text-success">Rahmat! Sharhingiz moderatsiyadan so&apos;ng chiqadi.</p>;
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rating) return;
    setSending(true);
    try {
      await venueService.createReview({ booking_id: bookingId, rating, comment: comment.trim() || null });
      setSent(true);
      toast("Sharh yuborildi");
    } catch (err) {
      toast(errorMessage(err, "Sharhni yuborib bo'lmadi"), "error");
    } finally {
      setSending(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-3">
      <fieldset>
        <legend className="font-bold text-ink">Tashrifingizni baholang</legend>
        <div className="mt-2 flex gap-1">
          {[1, 2, 3, 4, 5].map((value) => (
            <button
              key={value}
              type="button"
              aria-label={`${value} yulduz`}
              aria-pressed={rating === value}
              onClick={() => setRating(value)}
              className="flex h-11 w-11 items-center justify-center"
            >
              <Star className={`h-8 w-8 ${value <= rating ? "fill-warning text-warning" : "text-border"}`} aria-hidden="true" />
            </button>
          ))}
        </div>
      </fieldset>
      <label className="block">
        <span className="sr-only">Sharh</span>
        <textarea
          rows={3}
          maxLength={1000}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Taassurotlaringiz (ixtiyoriy)"
          className="w-full rounded-control border border-border bg-surface-100 px-4 py-3 text-base text-ink outline-none placeholder:text-ink-muted focus:border-brand"
        />
      </label>
      <Button type="submit" size="md" fullWidth disabled={!rating} loading={sending}>
        Sharh yuborish
      </Button>
    </form>
  );
}
