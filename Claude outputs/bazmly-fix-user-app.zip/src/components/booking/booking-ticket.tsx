"use client";

import React, { useState } from "react";
import { CalendarDays, Clock, CreditCard, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmSheet } from "@/components/ui/confirm-sheet";
import { useToast } from "@/components/ui/toast";
import { bookingService, type BookingOwnerDetail } from "@/lib/api";
import { canCancel, showsQr } from "@/lib/booking";
import { formatDate, formatDateTime, formatSom, formatTime } from "@/lib/format";
import { errorMessage } from "@/lib/use-api";
import { BookingQr } from "./booking-qr";
import { StatusBadge } from "./status-badge";

interface BookingTicketProps {
  detail: BookingOwnerDetail;
  /** Bekor qilingandan keyin yangilangan ma'lumot */
  onChanged?: (detail: BookingOwnerDetail) => void;
}

/** Bron chiptasi: holat, tafsilotlar, narx qatorlari va QR kod */
export function BookingTicket({ detail, onChanged }: BookingTicketProps) {
  const { booking } = detail;
  const toast = useToast();
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const deposit = Number(booking.deposit_amount || 0);

  const cancel = async () => {
    setCancelling(true);
    try {
      const updated = await bookingService.cancelBooking(booking.id);
      onChanged?.({ ...detail, booking: updated });
      toast("Bron bekor qilindi");
      setConfirmCancel(false);
    } catch (err) {
      toast(errorMessage(err, "Bronni bekor qilib bo'lmadi"), "error");
    } finally {
      setCancelling(false);
    }
  };

  return (
    <div className="overflow-hidden rounded-card bg-surface-100 shadow-[0_2px_12px_rgba(28,20,16,0.06)]">
      <div className="space-y-3 p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{booking.kind === "hall" ? "Zal broni" : "Stol broni"}</p>
            <h2 className="mt-0.5 text-xl font-extrabold text-ink">{detail.venue_name}</h2>
          </div>
          <StatusBadge status={booking.status} />
        </div>

        <ul className="grid grid-cols-2 gap-3 text-[15px] text-ink">
          <li className="flex items-center gap-2">
            <CalendarDays className="h-5 w-5 text-ink-muted" aria-hidden="true" />
            {formatDate(booking.booking_date)}
          </li>
          <li className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-ink-muted" aria-hidden="true" />
            {formatTime(booking.start_time)} – {formatTime(booking.end_time)}
          </li>
          <li className="flex items-center gap-2">
            <Users className="h-5 w-5 text-ink-muted" aria-hidden="true" />
            {booking.guests_count} kishi
          </li>
        </ul>

        {booking.status === "pending" && (
          <p className="rounded-control bg-brand-tint px-4 py-3 text-sm text-ink">
            Muassasa broningizni tasdiqlashi kutilmoqda.
            {booking.auto_cancel_at ? ` Tasdiqlanmasa ${formatDateTime(booking.auto_cancel_at)} da avtomatik bekor bo'ladi.` : ""}
          </p>
        )}
      </div>

      {showsQr(booking.status) && detail.qr_token && (
        <div className="flex flex-col items-center gap-2 border-t border-dashed border-border px-5 py-5">
          <BookingQr token={detail.qr_token} />
          <p className="text-center text-sm text-ink-muted">Muassasaga kelganingizda shu kodni ko&apos;rsating</p>
          <p className="text-sm font-bold tabular-nums tracking-wider text-ink">{booking.ticket_code}</p>
        </div>
      )}

      {detail.price_lines.length > 0 && (
        <div className="border-t border-border px-5 py-4">
          <ul className="space-y-2 text-[15px]">
            {[...detail.price_lines]
              .sort((a, b) => a.sort_order - b.sort_order)
              .map((line) => (
                <li key={line.id} className="flex justify-between gap-3">
                  <span className="text-ink-muted">
                    {line.label_snapshot}
                    {line.quantity > 1 ? ` × ${line.quantity}` : ""}
                  </span>
                  <span className="font-semibold text-ink">{formatSom(line.amount)}</span>
                </li>
              ))}
          </ul>
          <p className="mt-3 flex justify-between border-t border-border pt-3 text-base font-extrabold text-ink">
            <span>Jami</span>
            <span>{formatSom(booking.total_amount)}</span>
          </p>
        </div>
      )}

      {deposit > 0 && (booking.status === "pending" || booking.status === "confirmed") && (
        <div className="flex items-start gap-3 border-t border-border px-5 py-4">
          <CreditCard className="mt-0.5 h-5 w-5 shrink-0 text-brand-strong" aria-hidden="true" />
          <div>
            <p className="font-bold text-ink">Depozit: {formatSom(deposit)} — to&apos;lov kutilmoqda</p>
            <p className="mt-1 text-sm text-ink-muted">Onlayn to&apos;lov tez orada qo&apos;shiladi. Hozircha depozitni muassasa bilan kelishib to&apos;laysiz.</p>
          </div>
        </div>
      )}

      <div className="border-t border-border px-5 py-3 text-xs text-ink-muted">Chek raqami: {booking.receipt_number}</div>

      {canCancel(booking.status) && (
        <div className="px-5 pb-5">
          <Button variant="danger" size="md" fullWidth onClick={() => setConfirmCancel(true)}>
            Bronni bekor qilish
          </Button>
        </div>
      )}

      <ConfirmSheet
        open={confirmCancel}
        title="Bronni bekor qilish"
        text="Bron bekor qilinadi. Bekor qilish shartlari muassasaga bog'liq."
        confirmText="Bekor qilish"
        cancelText="Qoldirish"
        danger
        loading={cancelling}
        onConfirm={cancel}
        onClose={() => setConfirmCancel(false)}
      />
    </div>
  );
}
