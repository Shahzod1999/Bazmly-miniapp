"use client";

import React, { useState } from "react";
import { Minus, Plus } from "lucide-react";
import { Sheet } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { hapticSelection } from "@/lib/telegram";

const PRESETS = [2, 4, 10, 50, 100, 200, 300, 500];

interface GuestsFilterSheetProps {
  open: boolean;
  onClose: () => void;
  value: number | null;
  onApply: (value: number | null) => void;
}

export function GuestsFilterSheet({ open, onClose, value, onApply }: GuestsFilterSheetProps) {
  return (
    <Sheet open={open} onClose={onClose} title="Mehmonlar soni">
      {open && <GuestsForm initial={value} onApply={(v) => { onApply(v); onClose(); }} />}
    </Sheet>
  );
}

function GuestsForm({ initial, onApply }: { initial: number | null; onApply: (value: number | null) => void }) {
  const [count, setCount] = useState(initial ?? 4);

  const change = (next: number) => {
    setCount(Math.max(1, Math.min(2000, next)));
    hapticSelection();
  };

  return (
    <div className="pt-2">
      <p className="text-[15px] text-ink-muted">Shuncha mehmonni sig&apos;dira oladigan joylar ko&apos;rsatiladi.</p>
      <div className="mt-5 flex items-center justify-center gap-4">
        <button
          type="button"
          aria-label="Kamaytirish"
          onClick={() => change(count - (count > 20 ? 10 : 1))}
          className="flex h-12 w-12 items-center justify-center rounded-control bg-surface-200 text-ink"
        >
          <Minus className="h-5 w-5" aria-hidden="true" />
        </button>
        <output aria-live="polite" className="min-w-20 text-center text-3xl font-extrabold tabular-nums text-ink">
          {count}
        </output>
        <button
          type="button"
          aria-label="Ko'paytirish"
          onClick={() => change(count + (count >= 20 ? 10 : 1))}
          className="flex h-12 w-12 items-center justify-center rounded-control bg-surface-200 text-ink"
        >
          <Plus className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>
      <div className="mt-5 flex flex-wrap justify-center gap-2">
        {PRESETS.map((preset) => (
          <button
            key={preset}
            type="button"
            aria-pressed={count === preset}
            onClick={() => change(preset)}
            className={`h-11 rounded-full px-4 text-sm font-semibold ${
              count === preset ? "bg-brand-strong text-on-brand" : "bg-surface-200 text-ink"
            }`}
          >
            {preset}
          </button>
        ))}
      </div>
      <div className="mt-6 flex gap-3">
        <Button variant="secondary" fullWidth onClick={() => onApply(null)}>
          Tozalash
        </Button>
        <Button fullWidth onClick={() => onApply(count)}>
          Qo&apos;llash
        </Button>
      </div>
    </div>
  );
}
