"use client";

import React, { useState } from "react";
import { Check, ChevronDown, LocateFixed, MapPin } from "lucide-react";
import { Sheet } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { geoService, type DistrictRead } from "@/lib/api";
import { errorMessage, useApiQuery } from "@/lib/use-api";

export interface SelectedDistrict {
  id: number;
  name: string;
}

interface LocationSheetProps {
  open: boolean;
  onClose: () => void;
  selected: SelectedDistrict | null;
  onSelect: (district: SelectedDistrict | null) => void;
}

export function LocationSheet({ open, onClose, selected, onSelect }: LocationSheetProps) {
  const regions = useApiQuery(open ? "regions" : null, () => geoService.getRegions());
  const [openRegion, setOpenRegion] = useState<number | null>(null);
  const [detecting, setDetecting] = useState(false);
  const [geoError, setGeoError] = useState<string | null>(null);

  const choose = (district: SelectedDistrict | null) => {
    onSelect(district);
    onClose();
  };

  const detect = () => {
    if (!navigator.geolocation) {
      setGeoError("Qurilmangiz joylashuvni aniqlashni qo'llamaydi");
      return;
    }
    setDetecting(true);
    setGeoError(null);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const nearest = await geoService.getNearestDistrict(pos.coords.latitude, pos.coords.longitude);
          choose({ id: nearest.district_id, name: nearest.district_name });
        } catch (err) {
          setGeoError(errorMessage(err, "Eng yaqin tuman topilmadi"));
        } finally {
          setDetecting(false);
        }
      },
      () => {
        setDetecting(false);
        setGeoError("Joylashuvga ruxsat berilmadi");
      },
      { timeout: 10000 }
    );
  };

  return (
    <Sheet open={open} onClose={onClose} title="Manzilni tanlang">
      <Button variant="secondary" size="md" fullWidth onClick={detect} loading={detecting}>
        <LocateFixed className="h-5 w-5" aria-hidden="true" />
        Joylashuvimni aniqlash
      </Button>
      {geoError && (
        <p role="alert" className="mt-2 text-sm font-medium text-danger">
          {geoError}
        </p>
      )}

      <button
        type="button"
        onClick={() => choose(null)}
        className="mt-4 flex min-h-12 w-full items-center gap-3 rounded-control px-2 text-left font-semibold text-ink active:bg-surface-200"
      >
        <MapPin className="h-5 w-5 text-ink-muted" aria-hidden="true" />
        <span className="flex-1">Barcha hududlar</span>
        {!selected && <Check className="h-5 w-5 text-brand-strong" aria-label="Tanlangan" />}
      </button>

      {regions.state.status === "loading" && (
        <LoadingBlock>
          <div className="mt-2 space-y-2">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-12" />
            ))}
          </div>
        </LoadingBlock>
      )}
      {regions.state.status === "error" && <ErrorState message={regions.state.error.message} onRetry={regions.retry} />}
      {regions.state.status === "success" && (
        <ul className="mt-1 divide-y divide-border">
          {regions.state.data.map((region) => (
            <li key={region.id}>
              <button
                type="button"
                aria-expanded={openRegion === region.id}
                onClick={() => setOpenRegion((prev) => (prev === region.id ? null : region.id))}
                className="flex min-h-12 w-full items-center justify-between px-2 text-left font-semibold text-ink"
              >
                {region.name}
                <ChevronDown
                  className={`h-5 w-5 text-ink-muted transition-transform ${openRegion === region.id ? "rotate-180" : ""}`}
                  aria-hidden="true"
                />
              </button>
              {openRegion === region.id && (
                <DistrictList regionId={region.id} selectedId={selected?.id ?? null} onChoose={(d) => choose({ id: d.id, name: d.name })} />
              )}
            </li>
          ))}
        </ul>
      )}
    </Sheet>
  );
}

function DistrictList({
  regionId,
  selectedId,
  onChoose,
}: {
  regionId: number;
  selectedId: number | null;
  onChoose: (district: DistrictRead) => void;
}) {
  const districts = useApiQuery(`districts:${regionId}`, () => geoService.getDistricts(regionId));

  if (districts.state.status === "loading") {
    return (
      <LoadingBlock>
        <div className="space-y-2 pb-2 pl-4">
          <Skeleton className="h-10" />
          <Skeleton className="h-10" />
        </div>
      </LoadingBlock>
    );
  }
  if (districts.state.status === "error") {
    return (
      <div className="pb-2 pl-4">
        <Button variant="ghost" size="md" onClick={districts.retry}>
          Tumanlarni qayta yuklash
        </Button>
      </div>
    );
  }
  return (
    <ul className="pb-2 pl-4">
      {districts.state.data.map((district) => (
        <li key={district.id}>
          <button
            type="button"
            onClick={() => onChoose(district)}
            className="flex min-h-11 w-full items-center justify-between rounded-control px-2 text-left text-[15px] text-ink active:bg-surface-200"
          >
            {district.name}
            {selectedId === district.id && <Check className="h-5 w-5 text-brand-strong" aria-label="Tanlangan" />}
          </button>
        </li>
      ))}
    </ul>
  );
}
