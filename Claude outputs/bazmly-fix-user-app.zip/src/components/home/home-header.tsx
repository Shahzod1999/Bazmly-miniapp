"use client";

import React from "react";
import Link from "next/link";
import { Bell, ChevronDown, MapPin } from "lucide-react";
import { IconButton } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

interface HomeHeaderProps {
  districtName: string | null;
  unreadCount: number;
  onOpenLocation: () => void;
  onOpenNotifications: () => void;
}

export function HomeHeader({ districtName, unreadCount, onOpenLocation, onOpenNotifications }: HomeHeaderProps) {
  const { user } = useAuth();
  const greeting = user?.first_name ? `Hayrli kun, ${user.first_name}!` : "Hayrli kun!";

  return (
    <header className="flex items-start justify-between gap-3 px-4 pt-[calc(var(--tg-safe-top)+16px)]">
      <div className="min-w-0">
        <h1 className="truncate text-[22px] font-extrabold tracking-tight text-ink">{greeting}</h1>
        <button
          type="button"
          onClick={onOpenLocation}
          className="-ml-1 mt-0.5 flex min-h-11 items-center gap-1 rounded-control px-1 text-sm font-semibold text-ink-muted"
        >
          <MapPin className="h-4 w-4 text-brand-strong" aria-hidden="true" />
          <span className="truncate">{districtName ?? "Barcha hududlar"}</span>
          <ChevronDown className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
      {user ? (
        <IconButton label={unreadCount > 0 ? `Xabarnomalar, ${unreadCount} ta o'qilmagan` : "Xabarnomalar"} onClick={onOpenNotifications} className="relative bg-surface-100">
          <Bell className="h-5 w-5" aria-hidden="true" />
          {unreadCount > 0 && (
            <span className="absolute right-1.5 top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-danger px-1 text-xs font-bold text-white">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </IconButton>
      ) : (
        <Link href="/login" className="flex h-11 items-center rounded-control bg-brand px-4 text-base font-bold text-on-brand">
          Kirish
        </Link>
      )}
    </header>
  );
}
