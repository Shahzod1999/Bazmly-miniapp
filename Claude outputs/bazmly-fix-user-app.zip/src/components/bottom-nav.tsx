"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Heart, House, Ticket, UserRound } from "lucide-react";
import { hapticSelection } from "@/lib/telegram";

const TABS = [
  { href: "/", label: "Asosiy", icon: House, match: (p: string) => p === "/" },
  { href: "/feed", label: "Saqlangan", icon: Heart, match: (p: string) => p.startsWith("/feed") },
  { href: "/tickets", label: "Chiptalar", icon: Ticket, match: (p: string) => p.startsWith("/tickets") },
  { href: "/login", label: "Profil", icon: UserRound, match: (p: string) => p.startsWith("/login") },
];

/** Pastki navigatsiya faqat asosiy bo'limlarda ko'rinadi */
export const TAB_ROUTES = ["/", "/feed", "/tickets", "/login"];

export default function BottomNav() {
  const pathname = usePathname();
  if (!TAB_ROUTES.includes(pathname)) return null;

  return (
    <>
      <div aria-hidden="true" className="h-[calc(64px+var(--tg-safe-bottom))]" />
      <nav
        aria-label="Asosiy bo'limlar"
        className="fixed inset-x-0 bottom-0 z-50 mx-auto max-w-md border-t border-border bg-surface-100 pb-[var(--tg-safe-bottom)]"
      >
        <ul className="grid h-16 grid-cols-4">
          {TABS.map(({ href, label, icon: Icon, match }) => {
            const active = match(pathname);
            return (
              <li key={href}>
                <Link
                  href={href}
                  aria-current={active ? "page" : undefined}
                  onClick={() => !active && hapticSelection()}
                  className={`flex h-full flex-col items-center justify-center gap-1 text-xs font-semibold transition-colors ${
                    active ? "text-brand-strong" : "text-ink-muted"
                  }`}
                >
                  <Icon className="h-6 w-6" strokeWidth={active ? 2.4 : 1.9} aria-hidden="true" />
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}
