"use client";

import React, { useEffect, useState } from "react";
import { Search, SlidersHorizontal, Store, X } from "lucide-react";
import { HomeHeader } from "@/components/home/home-header";
import { LocationSheet, type SelectedDistrict } from "@/components/home/location-sheet";
import { GuestsFilterSheet } from "@/components/home/guests-filter-sheet";
import { NotificationsSheet } from "@/components/profile/notifications-sheet";
import { VenueCard, VenueCardSkeleton, venueHref } from "@/components/venue/venue-card";
import { EmptyState, ErrorState, LoadingBlock } from "@/components/ui/state-views";
import { useAuth } from "@/contexts/AuthContext";
import { engagementService, venueService, type VenueTypeSlug } from "@/lib/api";
import { hapticSelection } from "@/lib/telegram";
import { useApiQuery } from "@/lib/use-api";
import { useFavorites } from "@/lib/use-favorites";
import { useStoredValue } from "@/lib/use-stored";

const TABS: { label: string; type: VenueTypeSlug | null }[] = [
  { label: "Hammasi", type: null },
  { label: "Restoranlar", type: "restoran" },
  { label: "To'yxonalar", type: "toyxona" },
];

type Panel = "location" | "guests" | "notifications" | null;

export default function HomePage() {
  const { user } = useAuth();
  const favorites = useFavorites();
  const [panel, setPanel] = useState<Panel>(null);
  const [type, setType] = useState<VenueTypeSlug | null>(null);
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [guests, setGuests] = useState<number | null>(null);
  const [storedDistrict, setStoredDistrict] = useStoredValue("bazmly-district");
  const district = parseDistrict(storedDistrict);

  // Qidiruv so'rovini yozish tugagach yuboramiz
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query.trim()), 350);
    return () => clearTimeout(timer);
  }, [query]);

  const searchKey = JSON.stringify({ type, q: debouncedQuery, d: district?.id ?? null, g: guests });
  const venues = useApiQuery(searchKey, () =>
    venueService.searchVenues({
      query: debouncedQuery || undefined,
      venue_type: type ?? undefined,
      district_id: district?.id,
      guest_count: guests ?? undefined,
      limit: 30,
    })
  );

  const unread = useApiQuery(user ? `unread:${user.id}` : null, () => engagementService.getUnreadNotificationsCount());
  const unreadCount = unread.state.status === "success" ? unread.state.data : 0;

  const hasFilters = Boolean(debouncedQuery || guests || district);

  return (
    <div className="flex-1">
      <HomeHeader
        districtName={district?.name ?? null}
        unreadCount={unreadCount}
        onOpenLocation={() => setPanel("location")}
        onOpenNotifications={() => setPanel("notifications")}
      />

      <div className="mt-3 flex gap-2 px-4">
        <label className="flex h-12 flex-1 items-center gap-2 rounded-control bg-surface-100 px-3 shadow-[0_2px_12px_rgba(28,20,16,0.06)]">
          <Search className="h-5 w-5 shrink-0 text-ink-muted" aria-hidden="true" />
          <span className="sr-only">Joy qidirish</span>
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Restoran yoki to'yxona nomi"
            className="h-full min-w-0 flex-1 bg-transparent text-base text-ink outline-none placeholder:text-ink-muted"
          />
          {query && (
            <button type="button" aria-label="Qidiruvni tozalash" onClick={() => setQuery("")} className="-mr-2 flex h-11 w-11 items-center justify-center text-ink-muted">
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
          )}
        </label>
        <button
          type="button"
          onClick={() => setPanel("guests")}
          aria-label={guests ? `Mehmonlar soni: ${guests}` : "Mehmonlar soni bo'yicha saralash"}
          className={`relative flex h-12 w-12 shrink-0 items-center justify-center rounded-control ${
            guests ? "bg-brand-strong text-on-brand" : "bg-brand text-on-brand"
          }`}
        >
          <SlidersHorizontal className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>

      {guests && (
        <div className="mt-2 px-4">
          <button
            type="button"
            onClick={() => setGuests(null)}
            className="inline-flex h-9 items-center gap-1.5 rounded-full bg-brand-tint px-3 text-sm font-semibold text-brand-strong"
          >
            {guests} kishi
            <X className="h-4 w-4" aria-label="olib tashlash" />
          </button>
        </div>
      )}

      <nav aria-label="Joy turi" className="scrollbar-none mt-4 flex gap-2 overflow-x-auto px-4">
        {TABS.map((tab) => {
          const active = type === tab.type;
          return (
            <button
              key={tab.label}
              type="button"
              aria-pressed={active}
              onClick={() => {
                setType(tab.type);
                hapticSelection();
              }}
              className={`h-11 shrink-0 rounded-full px-5 text-[15px] font-semibold transition-colors ${
                active ? "bg-brand-strong text-on-brand" : "bg-surface-200 text-ink"
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </nav>

      <section aria-label="Joylar" className="mt-5 space-y-4 px-4 pb-6">
        {venues.state.status === "loading" && (
          <LoadingBlock label="Joylar yuklanmoqda">
            <div className="space-y-4">
              <VenueCardSkeleton />
              <VenueCardSkeleton />
            </div>
          </LoadingBlock>
        )}
        {venues.state.status === "error" && <ErrorState message={venues.state.error.message} onRetry={venues.retry} />}
        {venues.state.status === "success" && venues.state.data.items.length === 0 && (
          <EmptyState
            icon={<Store className="h-10 w-10" />}
            title="Hech narsa topilmadi"
            text={hasFilters ? "Qidiruv yoki filtrlarni o'zgartirib ko'ring." : "Bu hududda hozircha joylar yo'q."}
          />
        )}
        {venues.state.status === "success" &&
          venues.state.data.items.map((venue, index) => (
            <VenueCard
              key={venue.id}
              venue={venue}
              href={type ? venueHref(venue.id, type) : `/venue/${venue.id}`}
              priority={index === 0}
              isFavorite={favorites.ids.has(venue.id)}
              onToggleFavorite={favorites.toggle}
            />
          ))}
      </section>

      <LocationSheet
        open={panel === "location"}
        onClose={() => setPanel(null)}
        selected={district}
        onSelect={(d) => setStoredDistrict(d ? JSON.stringify(d) : null)}
      />
      <GuestsFilterSheet open={panel === "guests"} onClose={() => setPanel(null)} value={guests} onApply={setGuests} />
      <NotificationsSheet
        open={panel === "notifications"}
        onClose={() => {
          setPanel(null);
          unread.retry();
        }}
      />
    </div>
  );
}

/** Saqlangan tumanni xavfsiz o'qish (buzilgan qiymat bo'lsa e'tiborsiz qoldiramiz) */
function parseDistrict(value: string | null): SelectedDistrict | null {
  if (!value) return null;
  try {
    const parsed: unknown = JSON.parse(value);
    if (parsed && typeof parsed === "object" && typeof (parsed as SelectedDistrict).id === "number") return parsed as SelectedDistrict;
  } catch {
    // buzilgan JSON — tanlanmagan deb hisoblaymiz
  }
  return null;
}
