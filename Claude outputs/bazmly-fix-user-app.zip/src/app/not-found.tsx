import Link from "next/link";
import { SearchX } from "lucide-react";
import { EmptyState } from "@/components/ui/state-views";

export default function NotFound() {
  return (
    <div className="flex flex-1 flex-col justify-center pt-[var(--tg-safe-top)]">
      <EmptyState
        icon={<SearchX className="h-10 w-10" />}
        title="Sahifa topilmadi"
        text="Siz qidirgan sahifa mavjud emas yoki o'chirilgan."
        action={
          <Link href="/" className="flex h-12 items-center rounded-control bg-brand px-6 text-base font-bold text-on-brand">
            Bosh sahifaga qaytish
          </Link>
        }
      />
    </div>
  );
}
