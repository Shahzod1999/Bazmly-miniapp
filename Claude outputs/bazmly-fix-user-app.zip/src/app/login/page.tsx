"use client";

import { Suspense, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { AuthFlow } from "@/components/auth/auth-flow";
import { CompleteProfile } from "@/components/auth/complete-profile";
import { TelegramLoginCard } from "@/components/auth/telegram-login-card";
import { ProfileScreen } from "@/components/profile/profile-screen";
import { useAuth } from "@/contexts/AuthContext";
import { useIsTelegram } from "@/lib/telegram";

/** Faqat ilova ichidagi manzillarga qaytarish */
function safeNext(value: string | null): string | null {
  return value && value.startsWith("/") && !value.startsWith("//") ? value : null;
}

/** Kirmagan foydalanuvchi uchun kirish oynasi, kirgan foydalanuvchi uchun profil */
export default function LoginPage() {
  return (
    <Suspense fallback={<div className="flex-1" />}>
      <LoginContent />
    </Suspense>
  );
}

function LoginContent() {
  const { user, loading } = useAuth();
  const isTelegram = useIsTelegram();
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"));
  const profileReady = !!user && user.status !== "pending_profile" && !!user.first_name;

  // Kirish (Telegram yoki profilni to'ldirish) tugagach, boshlangan sahifaga qaytamiz
  useEffect(() => {
    if (profileReady && next) router.replace(next);
  }, [profileReady, next, router]);

  if (loading || (profileReady && next)) return <div className="flex-1" />;

  if (!user) {
    if (isTelegram) return <TelegramLoginCard />;
    return <AuthFlow />;
  }

  if (!profileReady) return <CompleteProfile />;

  return <ProfileScreen />;
}
