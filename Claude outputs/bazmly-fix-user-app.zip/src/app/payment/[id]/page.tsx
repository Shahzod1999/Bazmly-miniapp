"use client";

import React, { Suspense } from "react";
import { BookingResultScreen } from "@/components/booking/booking-result-screen";

/** Bron natijasi va to'lov holati (id — bron raqami) */
export default function PaymentPage() {
  return (
    <Suspense fallback={<div className="flex-1" />}>
      <BookingResultScreen />
    </Suspense>
  );
}
