"use client";

import Link from "next/link";
import { AlertTriangle, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/state-views";

export default function Error({ unstable_retry }: { error: Error & { digest?: string }; unstable_retry: () => void }) {
  return (
    <div className="flex flex-1 flex-col justify-center pt-[var(--tg-safe-top)]">
      <EmptyState
        icon={<AlertTriangle className="h-10 w-10" />}
        title="Nimadir xato ketdi"
        text="Sahifani ochib bo'lmadi. Qaytadan urinib ko'ring yoki bosh sahifaga qayting."
        action={
          <div className="flex flex-col items-center gap-3">
            <Button size="md" onClick={() => unstable_retry()}>
              <RotateCw className="h-5 w-5" aria-hidden="true" />
              Qayta urinish
            </Button>
            <Link href="/" className="flex h-11 items-center px-4 font-semibold text-brand-strong">
              Bosh sahifa
            </Link>
          </div>
        }
      />
    </div>
  );
}
