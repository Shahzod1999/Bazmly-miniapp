"use client";

import "./globals.css";

/** Ildiz layout'da xato bo'lsa ko'rsatiladi (o'z html/body teglariga ega) */
export default function GlobalError({ unstable_retry }: { error: Error & { digest?: string }; unstable_retry: () => void }) {
  return (
    <html lang="uz">
      <body className="bg-surface-0 font-sans text-ink antialiased">
        <title>Xatolik — Bazmly</title>
        <main className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-6 text-center">
          <h1 className="text-xl font-bold">Ilovani ochib bo&apos;lmadi</h1>
          <p className="mt-2 text-[15px] text-ink-muted">Internet aloqasini tekshiring va qaytadan urinib ko&apos;ring.</p>
          <button
            type="button"
            onClick={() => unstable_retry()}
            className="mt-6 h-12 rounded-control bg-brand px-6 text-base font-bold text-on-brand"
          >
            Qayta urinish
          </button>
        </main>
      </body>
    </html>
  );
}
