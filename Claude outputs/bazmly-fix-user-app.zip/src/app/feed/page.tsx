"use client";

import React from "react";
import Link from "next/link";
import { Heart } from "lucide-react";
import { RequireAuth } from "@/components/auth/require-auth";
import { VenueCard, VenueCardSkeleton, venueHref } from "@/components/venue/venue-card";
import { EmptyState, ErrorState, LoadingBlock } from "@/components/ui/state-views";
import { engagementService } from "@/lib/api";
import { useApiQuery } from "@/lib/use-api";
import { useFavorites } from "@/lib/use-favorites";

/** Saqlangan joylar */
export default function FeedPage() {
  return (
    <RequireAuth title="Saqlanganlar">
      <Favorites />
    </RequireAuth>
  );
}

function Favorites() {
  const list = useApiQuery("favorites-list", () => engagementService.getFavorites());
  const favorites = useFavorites();
  const { state } = list;
  const items = state.status === "success" ? state.data : [];

  return (
    <div className="flex-1 px-4 pt-[calc(var(--tg-safe-top)+16px)] pb-6">
      <h1 className="text-[22px] font-extrabold tracking-tight text-ink">Saqlanganlar</h1>
      <div className="mt-4">
        {state.status === "loading" && (
          <LoadingBlock label="Saqlanganlar yuklanmoqda">
            <div className="space-y-4">
              <VenueCardSkeleton />
              <VenueCardSkeleton />
            </div>
          </LoadingBlock>
        )}
        {state.status === "error" && <ErrorState message={state.error.message} onRetry={list.retry} />}
        {state.status === "success" && items.length === 0 && (
          <EmptyState
            icon={<Heart className="h-10 w-10" />}
            title="Hali hech narsa saqlanmagan"
            text="Yoqqan restoran va to'yxonalarni yurakcha tugmasi bilan saqlang."
            action={
              <Link href="/" className="flex h-12 items-center rounded-control bg-brand px-6 text-base font-bold text-on-brand">
                Joylarni ko&apos;rish
              </Link>
            }
          />
        )}
        {items.length > 0 && (
          <ul className="space-y-4">
            {items.map(({ venue }) => (
              <li key={venue.id}>
                <VenueCard
                  venue={venue}
                  href={venueHref(venue.id)}
                  isFavorite
                  onToggleFavorite={async () => {
                    await favorites.toggle(venue.id);
                    list.retry();
                  }}
                />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
