"use client";

import React, { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ChevronLeft, MessageCircle, Phone, Store } from "lucide-react";
import { VenueGallery } from "@/components/venue/venue-gallery";
import { VenueInfo } from "@/components/venue/venue-info";
import { VenueMenu, cartSummary, encodeCart, type Cart } from "@/components/venue/venue-menu";
import { ReviewsSheet } from "@/components/venue/reviews-sheet";
import { ChatSheet } from "@/components/venue/chat-sheet";
import { BottomAction, BottomActionSpacer } from "@/components/ui/bottom-action";
import { IconButton } from "@/components/ui/button";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { useAuth } from "@/contexts/AuthContext";
import { isApiError, venueService } from "@/lib/api";
import { formatSom } from "@/lib/format";
import { useIsTelegram, useTelegramBackButton } from "@/lib/telegram";
import { useApiQuery } from "@/lib/use-api";
import { useFavorites } from "@/lib/use-favorites";
import { useShare } from "@/lib/use-share";

type Panel = "reviews" | "chat" | null;

export default function VenueDetailPage() {
  const { id } = useParams<{ id: string }>();
  const venueId = Number(id);
  const router = useRouter();
  const { user } = useAuth();
  const isTelegram = useIsTelegram();
  const favorites = useFavorites();
  const share = useShare();
  const [panel, setPanel] = useState<Panel>(null);
  const [cart, setCart] = useState<Cart>({});

  useTelegramBackButton(() => router.back());

  const detail = useApiQuery(Number.isInteger(venueId) ? `venue:${venueId}` : null, () => venueService.getVenueDetail(venueId));
  const menu = useApiQuery(Number.isInteger(venueId) ? `menu:${venueId}` : null, () => venueService.getMenu(venueId));

  // To'yxonalar o'z sahifasida ochiladi
  const isHall = detail.state.status === "success" && detail.state.data.venue_type === "toyxona";
  useEffect(() => {
    if (isHall) router.replace(`/toyxona/${venueId}`);
  }, [isHall, router, venueId]);

  const summary = menu.state.status === "success" ? cartSummary(cart, menu.state.data) : { count: 0, total: 0 };

  const goToBooking = () => {
    const items = encodeCart(cart);
    const target = `/booking/${venueId}${items ? `?items=${items}` : ""}`;
    if (!user) router.push(`/login?next=${encodeURIComponent(target)}`);
    else router.push(target);
  };

  const backButton = !isTelegram ? (
    <IconButton label="Orqaga" tone="overlay" onClick={() => router.back()}>
      <ChevronLeft className="h-6 w-6" />
    </IconButton>
  ) : null;

  if (detail.state.status === "loading" || isHall) {
    return (
      <LoadingBlock label="Joy ma'lumotlari yuklanmoqda">
        <Skeleton className="h-72 rounded-none" />
        <div className="space-y-3 p-4">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-5 w-1/2" />
          <Skeleton className="h-20" />
        </div>
      </LoadingBlock>
    );
  }

  if (detail.state.status === "error") {
    const notFound = isApiError(detail.state.error) && detail.state.error.status === 404;
    return (
      <div className="pt-[calc(var(--tg-safe-top)+12px)]">
        <div className="px-2">{backButton && <IconButton label="Orqaga" onClick={() => router.back()}><ChevronLeft className="h-6 w-6" /></IconButton>}</div>
        {notFound ? (
          <EmptyState icon={<Store className="h-10 w-10" />} title="Joy topilmadi" text="Bu joy o'chirilgan yoki manzil noto'g'ri." />
        ) : (
          <ErrorState message={detail.state.error.message} onRetry={detail.retry} />
        )}
      </div>
    );
  }

  const data = detail.state.data;
  const { venue } = data;

  return (
    <div className="flex-1">
      <VenueGallery
        name={venue.name}
        photos={data.photos}
        isFavorite={favorites.ids.has(venue.id)}
        onToggleFavorite={() => favorites.toggle(venue.id)}
        onShare={() => share(venue.name)}
        backButton={backButton}
      />

      <div className="px-4 pt-5">
        <VenueInfo detail={data} onOpenReviews={() => setPanel("reviews")} priceLabel="O'rtacha chek" />

        <div className="mt-4 grid grid-cols-2 gap-3">
          <a href={`tel:${venue.phone}`} className="flex h-12 items-center justify-center gap-2 rounded-control bg-surface-200 font-semibold text-ink">
            <Phone className="h-5 w-5" aria-hidden="true" />
            Qo&apos;ng&apos;iroq
          </a>
          <button
            type="button"
            onClick={() => (user ? setPanel("chat") : router.push(`/login?next=${encodeURIComponent(`/venue/${venueId}`)}`))}
            className="flex h-12 items-center justify-center gap-2 rounded-control bg-surface-200 font-semibold text-ink"
          >
            <MessageCircle className="h-5 w-5" aria-hidden="true" />
            Xabar yozish
          </button>
        </div>

        <VenueMenu menu={menu} cart={cart} onChange={setCart} />
      </div>

      <BottomActionSpacer withSummary={summary.count > 0} />
      <BottomAction
        text="Stol bron qilish"
        onClick={goToBooking}
        summary={
          summary.count > 0 ? (
            <p className="flex items-center justify-between text-[15px] text-ink">
              <span className="text-ink-muted">{summary.count} ta taom tanlandi</span>
              <span className="font-extrabold">{formatSom(summary.total)}</span>
            </p>
          ) : undefined
        }
      />

      <ReviewsSheet venueId={venue.id} open={panel === "reviews"} onClose={() => setPanel(null)} />
      {user && <ChatSheet venueId={venue.id} venueName={venue.name} open={panel === "chat"} onClose={() => setPanel(null)} />}
    </div>
  );
}
