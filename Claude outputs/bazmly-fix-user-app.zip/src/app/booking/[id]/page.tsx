"use client";

import React, { Suspense } from "react";
import { BookTableScreen } from "@/components/booking/book-table-screen";

export default function BookingPage() {
  return (
    <Suspense fallback={<div className="flex-1" />}>
      <BookTableScreen />
    </Suspense>
  );
}
