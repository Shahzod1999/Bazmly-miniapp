"use client";

import { Suspense, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";

function Redirect() {
  const router = useRouter();
  const bookingId = useSearchParams().get("bookingId");

  // To'lov holati bron sahifasida, API ma'lumoti asosida ko'rsatiladi
  useEffect(() => {
    router.replace(bookingId && /^\d+$/.test(bookingId) ? `/payment/${bookingId}` : "/tickets");
  }, [bookingId, router]);

  return <div className="flex-1" />;
}

export default function PaymentSuccessPage() {
  return (
    <Suspense fallback={<div className="flex-1" />}>
      <Redirect />
    </Suspense>
  );
}
