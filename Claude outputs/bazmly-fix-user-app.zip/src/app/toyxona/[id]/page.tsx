"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { ChevronLeft, ChevronRight, MessageCircle, Phone, Store, UtensilsCrossed } from "lucide-react";
import { VenueGallery } from "@/components/venue/venue-gallery";
import { VenueInfo } from "@/components/venue/venue-info";
import { ReviewsSheet } from "@/components/venue/reviews-sheet";
import { ChatSheet } from "@/components/venue/chat-sheet";
import { HallServicesList } from "@/components/toyxona/hall-services";
import { BottomAction, BottomActionSpacer } from "@/components/ui/bottom-action";
import { IconButton } from "@/components/ui/button";
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from "@/components/ui/state-views";
import { useAuth } from "@/contexts/AuthContext";
import { isApiError, venueService } from "@/lib/api";
import { useIsTelegram, useTelegramBackButton } from "@/lib/telegram";
import { useApiQuery } from "@/lib/use-api";
import { useFavorites } from "@/lib/use-favorites";
import { useShare } from "@/lib/use-share";

type Panel = "reviews" | "chat" | null;

export default function ToyxonaDetailPage() {
  const { id } = useParams<{ id: string }>();
  const venueId = Number(id);
  const valid = Number.isInteger(venueId) && venueId > 0;
  const router = useRouter();
  const { user } = useAuth();
  const isTelegram = useIsTelegram();
  const favorites = useFavorites();
  const share = useShare();
  const [panel, setPanel] = useState<Panel>(null);

  useTelegramBackButton(() => router.back());

  const detail = useApiQuery(valid ? `venue:${venueId}` : null, () => venueService.getVenueDetail(venueId));
  const venue = detail.state.status === "success" ? detail.state.data.venue : null;
  const services = useApiQuery(venue ? `services:${venueId}` : null, () =>
    venueService.getServices(venueId, (venue as NonNullable<typeof venue>).venue_group_id)
  );

  // Restoranlar o'z sahifasida ochiladi
  const isRestaurant = detail.state.status === "success" && detail.state.data.venue_type !== "toyxona";
  useEffect(() => {
    if (isRestaurant) router.replace(`/venue/${venueId}`);
  }, [isRestaurant, router, venueId]);

  const bookPath = `/toyxona/${venueId}/book`;
  const goToBooking = () => router.push(user ? bookPath : `/login?next=${encodeURIComponent(bookPath)}`);

  const backButton = !isTelegram ? (
    <IconButton label="Orqaga" tone="overlay" onClick={() => router.back()}>
      <ChevronLeft className="h-6 w-6" />
    </IconButton>
  ) : null;

  if (!valid || detail.state.status === "error") {
    const notFound = !valid || (detail.state.status === "error" && isApiError(detail.state.error) && detail.state.error.status === 404);
    return (
      <div className="pt-[calc(var(--tg-safe-top)+12px)]">
        {!isTelegram && (
          <div className="px-2">
            <IconButton label="Orqaga" onClick={() => router.back()}>
              <ChevronLeft className="h-6 w-6" />
            </IconButton>
          </div>
        )}
        {notFound ? (
          <EmptyState icon={<Store className="h-10 w-10" />} title="To'yxona topilmadi" text="Bu to'yxona o'chirilgan yoki manzil noto'g'ri." />
        ) : (
          detail.state.status === "error" && <ErrorState message={detail.state.error.message} onRetry={detail.retry} />
        )}
      </div>
    );
  }

  if (detail.state.status === "loading" || isRestaurant) {
    return (
      <LoadingBlock label="To'yxona ma'lumotlari yuklanmoqda">
        <Skeleton className="h-72 rounded-none" />
        <div className="space-y-3 p-4">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-5 w-1/2" />
          <Skeleton className="h-20" />
        </div>
      </LoadingBlock>
    );
  }

  const data = detail.state.data;
  const hall = data.venue;

  return (
    <div className="flex-1">
      <VenueGallery
        name={hall.name}
        photos={data.photos}
        isFavorite={favorites.ids.has(hall.id)}
        onToggleFavorite={() => favorites.toggle(hall.id)}
        onShare={() => share(hall.name)}
        backButton={backButton}
      />

      <div className="px-4 pt-5">
        <VenueInfo detail={data} onOpenReviews={() => setPanel("reviews")} priceLabel="Narx (1 kishi)" />

        <div className="mt-4 grid grid-cols-2 gap-3">
          <a href={`tel:${hall.phone}`} className="flex h-12 items-center justify-center gap-2 rounded-control bg-surface-200 font-semibold text-ink">
            <Phone className="h-5 w-5" aria-hidden="true" />
            Qo&apos;ng&apos;iroq
          </a>
          <button
            type="button"
            onClick={() => (user ? setPanel("chat") : router.push(`/login?next=${encodeURIComponent(`/toyxona/${venueId}`)}`))}
            className="flex h-12 items-center justify-center gap-2 rounded-control bg-surface-200 font-semibold text-ink"
          >
            <MessageCircle className="h-5 w-5" aria-hidden="true" />
            Xabar yozish
          </button>
        </div>

        <Link
          href={`/toyxona/${venueId}/menu`}
          className="mt-4 flex items-center gap-3 rounded-card bg-surface-100 p-4 shadow-[0_2px_12px_rgba(28,20,16,0.06)]"
        >
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-control bg-brand-tint text-brand-strong" aria-hidden="true">
            <UtensilsCrossed className="h-5 w-5" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-bold text-ink">Menyu paketlari</span>
            <span className="block text-sm text-ink-muted">Dasturxon va taomlar</span>
          </span>
          <ChevronRight className="h-5 w-5 text-ink-muted" aria-hidden="true" />
        </Link>

        <h2 className="mb-3 mt-6 text-lg font-bold text-ink">Qo&apos;shimcha xizmatlar</h2>
        <HallServicesList query={services} />
      </div>

      <BottomActionSpacer />
      <BottomAction text="Sanani band qilish" onClick={goToBooking} />

      <ReviewsSheet venueId={hall.id} open={panel === "reviews"} onClose={() => setPanel(null)} />
      {user && <ChatSheet venueId={hall.id} venueName={hall.name} open={panel === "chat"} onClose={() => setPanel(null)} />}
    </div>
  );
}
