"use client";

import React from "react";
import { HallBookingScreen } from "@/components/toyxona/hall-booking-screen";

export default function HallBookingPage() {
  return <HallBookingScreen />;
}
