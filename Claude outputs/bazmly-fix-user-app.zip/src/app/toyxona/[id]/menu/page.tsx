"use client";

import React from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { UtensilsCrossed } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { EmptyState } from "@/components/ui/state-views";
import { useTelegramBackButton } from "@/lib/telegram";

/**
 * To'yxona menyu paketlari.
 * Backend'da paketlar endpointi hali yo'q, shuning uchun ekran "Tez orada" holatida.
 * Dizayn komponentlari `src/components/toyxona-menu/` da tayyor turadi.
 */
export default function ToyxonaMenuPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  useTelegramBackButton(() => router.back());

  return (
    <div className="flex-1">
      <PageHeader title="Menyu paketlari" back />
      <EmptyState
        icon={<UtensilsCrossed className="h-10 w-10" />}
        title="Tez orada"
        text="Menyu paketlari va narxlar tez orada shu yerda chiqadi. Hozircha menyuni to'yxona bilan bron qilgach kelishib olasiz."
        action={
          <Link href={`/toyxona/${id}/book`} className="flex h-12 items-center rounded-control bg-brand px-6 text-base font-bold text-on-brand">
            Sanani band qilish
          </Link>
        }
      />
    </div>
  );
}
