import type { Metadata, Viewport } from "next";
import Script from "next/script";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { TelegramProvider } from "@/components/telegram-provider";
import { AuthProvider } from "@/contexts/AuthContext";
import { ToastProvider } from "@/components/ui/toast";
import BottomNav from "@/components/bottom-nav";
import SplashScreen from "@/components/splash-screen";

const plusJakartaSans = Plus_Jakarta_Sans({
  variable: "--font-plus-jakarta-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "Bazmly",
  description: "Restoran va to'yxonalarni topish va bron qilish uchun Telegram Mini App.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#1e1a18" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="uz" className={`${plusJakartaSans.variable} antialiased`} suppressHydrationWarning>
      <body className="flex min-h-full justify-center bg-surface-0 text-ink">
        {/* Telegram Mini App SDK: window.Telegram.WebApp */}
        <Script src="https://telegram.org/js/telegram-web-app.js" strategy="beforeInteractive" />
        <ThemeProvider>
          <TelegramProvider />
          <AuthProvider>
            <ToastProvider>
              <SplashScreen />
              {/* Brauzerda telefon kengligidagi ramka; Telegram ichida chegara yo'q */}
              <div className="app-frame min-h-app relative flex w-full max-w-md flex-col bg-surface-0">
                {children}
                <BottomNav />
              </div>
            </ToastProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
