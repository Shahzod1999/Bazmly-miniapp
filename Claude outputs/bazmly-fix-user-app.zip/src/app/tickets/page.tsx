"use client";

import React, { Suspense } from "react";
import { TicketsScreen } from "@/components/booking/tickets-screen";

export default function TicketsPage() {
  return (
    <Suspense fallback={<div className="flex-1" />}>
      <TicketsScreen />
    </Suspense>
  );
}
