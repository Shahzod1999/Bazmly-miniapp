export default function Loading() {
  return (
    <div role="status" aria-label="Yuklanmoqda" className="flex flex-1 items-center justify-center py-24">
      <span className="h-10 w-10 animate-spin rounded-full border-4 border-border border-t-brand" aria-hidden="true" />
    </div>
  );
}
