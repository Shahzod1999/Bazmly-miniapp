import { expect, test } from "@playwright/test";
import { hallItem, page as pageOf, restaurantItem } from "../fixtures/data";
import { mockApi, mockTelegram } from "../fixtures/mock-api";

test.beforeEach(async ({ page }) => {
  await mockTelegram(page);
});

test("bosh sahifa API'dan kelgan joylarni ko'rsatadi", async ({ page }) => {
  await mockApi(page, { "GET /api/v1/venues/search": { body: pageOf([restaurantItem, hallItem]) } });
  await page.goto("/");
  await expect(page.getByText("Afsona restorani")).toBeVisible();
  await expect(page.getByText("Navro'z to'yxonasi")).toBeVisible();
});

test("bo'sh natija holati", async ({ page }) => {
  await mockApi(page, { "GET /api/v1/venues/search": { body: pageOf([]) } });
  await page.goto("/");
  await expect(page.getByText("Hech narsa topilmadi")).toBeVisible();
});

test("xato holati va qayta urinish", async ({ page }) => {
  let fail = true;
  await mockApi(page, {
    "GET /api/v1/venues/search": () => (fail ? { status: 500, body: { message: "Server xatosi" } } : { body: pageOf([restaurantItem]) }),
  });
  await page.goto("/");
  await expect(page.getByText("Ma'lumotni yuklab bo'lmadi")).toBeVisible();
  fail = false;
  await page.getByRole("button", { name: "Qayta urinish" }).click();
  await expect(page.getByText("Afsona restorani")).toBeVisible();
});

test("/admin mavjud emas (404)", async ({ page }) => {
  await mockApi(page, {});
  const response = await page.goto("/admin");
  expect(response?.status()).toBe(404);
  await expect(page.getByText("Sahifa topilmadi")).toBeVisible();
});
