import { expect, test } from "@playwright/test";
import { hallBooking, hallDetail, hallServices } from "../fixtures/data";
import { mockApi, mockTelegram, signIn } from "../fixtures/mock-api";

test("to'yxona: sahifa → sana band qilish → bron", async ({ page }) => {
  await mockTelegram(page);
  const base = await signIn(page);
  const api = await mockApi(page, {
    ...base,
    "GET /api/v1/venues/20": { body: hallDetail },
    "GET /api/v1/venues/20/services": { body: hallServices },
    "GET /api/v1/venues/20/reviews": { body: { items: [], total: 0, limit: 20, offset: 0 } },
    "GET /api/v1/venues/20/availability": { body: { venue_id: 20, dates: [] } },
    "POST /api/v1/bookings/hall": { status: 201, body: hallBooking },
    "GET /api/v1/bookings/88": { body: hallBooking },
  });

  await page.goto("/toyxona/20");
  await expect(page.getByRole("heading", { name: "Navro'z to'yxonasi" })).toBeVisible();
  await expect(page.getByText("Karnay-surnay").first()).toBeVisible();
  await page.getByRole("button", { name: "Sanani band qilish" }).click();

  await expect(page).toHaveURL(/\/toyxona\/20\/book$/);
  await page.getByRole("radiogroup", { name: "Sana" }).getByRole("radio").nth(2).click();
  await page.getByRole("radiogroup", { name: "Vaqt" }).getByRole("radio").first().click();
  await page.getByRole("checkbox", { name: /Karnay-surnay/ }).click();
  await page.getByRole("button", { name: "Band qilish" }).click();

  await expect(page).toHaveURL(/\/payment\/88$/);
  await expect(page.getByText(/to'lov kutilmoqda/)).toBeVisible();
  expect(api.find("POST /api/v1/bookings/hall")?.body).toMatchObject({ venue_id: 20, guests_count: 100, venue_service_ids: [301] });
});

test("to'yxona menyu paketlari — 'Tez orada' (endpoint yo'q)", async ({ page }) => {
  await mockTelegram(page);
  await mockApi(page, {});
  await page.goto("/toyxona/20/menu");
  await expect(page.getByRole("heading", { name: "Tez orada" })).toBeVisible();
});
